#!/usr/bin/env python3
"""Experiment 7: fixed-rank optimization audit on recorded experiment-6 data.
No new quantum measurements, no physical simulator, no changes to original files.
Only PyTorch and Python standard library. CPU float64/complex128 intentionally.
This is a POST-HOC diagnostic, not a new held-out validation result.
The old selected rank is frozen; continuation uses the old combined data.
Multiple starts are chosen by measured-data likelihood, NEVER spectral error.
Archived Python is NOT executed. Independent checkpoints allow safe resumption.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, math, os, platform, statistics, sys, time, traceback, zipfile
from pathlib import Path
from datetime import datetime, timezone
import torch
CDTYPE=torch.complex128
RDTYPE=torch.float64
VERSION='0.7.0-fixed-rank-optimization-audit'

def integral(y: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
    return torch.sum((y[..., 1:] + y[..., :-1]) * (x[1:] - x[:-1]) * 0.5, dim=-1)

def dump_json(path: Path, value: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    tmp.replace(path)

def check(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)

def green(K: torch.Tensor, b: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
    ev, vec = torch.linalg.eigh((K + K.mH) * 0.5)
    weight = torch.abs(vec.mH @ b).square()
    return torch.sum(weight[:, None] / (z[None, :] - ev[:, None]), dim=0)

class SettingLayout:
    """Public measurement geometry, without exact probabilities or spectra."""
    def __init__(self, q: list[int], device: torch.device):
        check(q[0] == 0 and len(set(q)) == len(q), 'Invalid source/time layout.')
        self.q = q.copy()
        self.m = len(q)
        self.keys: list[tuple] = []
        overlap_directions, h_directions, costs = [], [], []
        lags = sorted({abs(i-j) for i in q for j in q if i != j})
        for d in lags:
            for part in ('R', 'I'):
                E = torch.zeros((self.m, self.m), dtype=CDTYPE)
                for i in range(self.m):
                    for j in range(self.m):
                        if q[j]-q[i] == d:
                            E[i,j] = 1 if part == 'R' else 1j
                        elif q[j]-q[i] == -d:
                            E[i,j] = 1 if part == 'R' else -1j
                self.keys.append(('S', d, part))
                overlap_directions.append(E)
                costs.append(abs(d))
        self.ns = len(self.keys)
        for i in range(self.m):
            for j in range(i, self.m):
                for part in (('R',) if i == j else ('R', 'I')):
                    E = torch.zeros((self.m, self.m), dtype=CDTYPE)
                    E[i,j] = 1 if part == 'R' else 1j
                    E[j,i] = E[i,j].conj()
                    self.keys.append(('H', i, j, part))
                    h_directions.append(E)
                    costs.append(abs(q[i])+abs(q[j]))
        self.nsettings = len(self.keys)
        self.ES = torch.stack(overlap_directions).to(device)
        self.EH = torch.stack(h_directions).to(device)
        self.time_tick_cost = torch.tensor(costs, dtype=torch.int64)
        self.device = device

    def matrices(self, observations: torch.Tensor, info: dict) -> tuple[torch.Tensor,torch.Tensor]:
        mu = observations.to(device=self.device, dtype=CDTYPE)
        S = torch.eye(self.m, dtype=CDTYPE, device=self.device)
        S = S + torch.einsum('k,kij->ij', mu[:self.ns], self.ES)
        Hbar = info['scale'] * torch.einsum('k,kij->ij', mu[self.ns:], self.EH)
        return S, info['sign'] * (Hbar - info['shift']*S)

def binomial_deviance(pred:torch.Tensor, observed:torch.Tensor,
                      counts:torch.Tensor) -> torch.Tensor:
    """Per-shot KL(observed Bernoulli || predicted Bernoulli).
    Saturated-model constant removed. Same minimizer as exact binomial NLL.
    Tiny probability clipping is numerical, not an uncertainty guarantee.
    """
    p=((1+pred)/2).clamp(1e-12,1-1e-12)
    q=((1+observed.to(pred.device))/2).clamp(0,1)
    entropy=torch.where(q>0,q*torch.log(q.clamp_min(1e-300)),torch.zeros_like(q))
    entropy+=torch.where(q<1,(1-q)*torch.log1p(-q.clamp_max(1-1e-15)),torch.zeros_like(q))
    dev=entropy-q*torch.log(p)-(1-q)*torch.log1p(-p)
    n=counts.to(device=pred.device,dtype=RDTYPE)
    return (n*dev).sum()/n.sum()

class LatentPhysicalModel(torch.nn.Module):
    """Unitary phase model + a separate Hermitian contraction for energy.
    General A uses A=I-2(I+R^dagger R)^-1; thus -I<=A<I by construction.
    Diagonal A is an ablation; it forces energy and time propagator to commute.
    """
    def __init__(self, layout:SettingLayout, rank:int, theta:torch.Tensor,
                 weights:torch.Tensor, energy:torch.Tensor, diagonal:bool):
        super().__init__();self.layout=layout;self.rank=rank;self.diagonal=diagonal
        self.theta=torch.nn.Parameter(theta.clone().real)
        self.logits=torch.nn.Parameter(weights.clamp_min(1e-12).log())
        if diagonal:
            self.energy_raw=torch.nn.Parameter(torch.atanh(energy.diag().real.clamp(-.98,.98)))
        else:
            ee,V=torch.linalg.eigh((energy+energy.mH)/2)
            dd=(1+ee.clamp(-.98,.98))/(1-ee.clamp(-.98,.98))
            R=dd.sqrt()[:,None]*V.mH
            self.energy_raw=torch.nn.Parameter(torch.view_as_real(R).contiguous())
        self.register_buffer('q',torch.tensor(layout.q,dtype=RDTYPE,device=layout.device))
        keys=layout.keys
        self.register_buffer('lag',torch.tensor([k[1] for k in keys[:layout.ns]],dtype=RDTYPE,device=layout.device))
        self.register_buffer('s_imag',torch.tensor([k[-1]=='I' for k in keys[:layout.ns]],device=layout.device))
        self.register_buffer('hi',torch.tensor([k[1] for k in keys[layout.ns:]],device=layout.device))
        self.register_buffer('hj',torch.tensor([k[2] for k in keys[layout.ns:]],device=layout.device))
        self.register_buffer('h_imag',torch.tensor([k[-1]=='I' for k in keys[layout.ns:]],device=layout.device))
    def core(self):
        w=self.logits.softmax(0)
        V=w.sqrt()[:,None]*torch.exp(-1j*self.theta[:,None]*self.q[None,:])
        if self.diagonal:A=torch.diag(torch.tanh(self.energy_raw).to(CDTYPE))
        else:
            R=torch.view_as_complex(self.energy_raw)
            I=torch.eye(self.rank,device=R.device,dtype=CDTYPE)
            A=I-2*torch.linalg.solve(I+R.mH@R,I)
            A=(A+A.mH)/2
        return w,V,A
    def forward(self):
        w,V,A=self.core()
        ss=(w[:,None]*torch.exp(-1j*self.theta[:,None]*self.lag[None,:])).sum(0)
        hh=(V.mH@A@V)[self.hi,self.hj]
        return torch.cat((torch.where(self.s_imag,ss.imag,ss.real),
                          torch.where(self.h_imag,hh.imag,hh.real)))
    def green(self,info:dict,z:torch.Tensor):
        w,V,A=self.core()
        K=info['sign']*(info['scale']*A-info['shift']*torch.eye(self.rank,device=A.device,dtype=CDTYPE))
        return green(K,info['beta']*w.sqrt().to(CDTYPE),z)


def snapshot(model):
    with torch.no_grad():
        w,V,A=model.core()
        return {'phases':model.theta.tolist(),'weights':w.tolist(),
                'energy_real':A.real.tolist(),'energy_imag':A.imag.tolist()}


def restore(layout, saved, diagonal):
    theta=torch.tensor(saved['phases'],dtype=RDTYPE)
    w=torch.tensor(saved['weights'],dtype=RDTYPE)
    A=torch.complex(torch.tensor(saved['energy_real'],dtype=RDTYPE),
                    torch.tensor(saved['energy_imag'],dtype=RDTYPE))
    model=LatentPhysicalModel(layout,len(w),theta,w,A,diagonal)
    # Constructor clips initial energies to .98: do NOT clip saved fitted energies.
    with torch.no_grad():
        model.logits.copy_(w.log())
        if diagonal:
            model.energy_raw.copy_(torch.atanh(A.diag().real.clamp(-1+1e-13,1-1e-13)))
        else:
            ee,V=torch.linalg.eigh((A+A.mH)/2)
            ee=ee.clamp(-1+1e-13,1-1e-13)
            R=((1+ee)/(1-ee)).sqrt()[:,None]*V.mH
            model.energy_raw.copy_(torch.view_as_real(R).contiguous())
        _,_,restored=model.core()
        check(float((restored-A).abs().max())<1e-8,'Snapshot restoration changed energy matrix.')
    return model


def perturb(model, token):
    digest=hashlib.sha256(token.encode()).digest()
    gen=torch.Generator().manual_seed(int.from_bytes(digest[:8],'little')%(2**63-1))
    with torch.no_grad():
        model.theta.add_(.015*torch.randn(model.theta.shape,generator=gen,dtype=RDTYPE))
        model.logits.add_(.03*torch.randn(model.logits.shape,generator=gen,dtype=RDTYPE))
        model.energy_raw.add_(.015*torch.randn(model.energy_raw.shape,generator=gen,dtype=RDTYPE))


def fit_audit(model,y,n,max_steps):
    """Same likelihood/optimizer settings as experiment 6; fresh final gradient."""
    clock=time.perf_counter(); calls=0
    opt=torch.optim.LBFGS(model.parameters(),lr=1.,max_iter=max_steps,
        line_search_fn='strong_wolfe',history_size=30,tolerance_grad=1e-7,tolerance_change=1e-10)
    initial=float(binomial_deviance(model(),y,n).detach())
    def closure():
        nonlocal calls
        calls+=1;opt.zero_grad()
        loss=1e4*binomial_deviance(model(),y,n)
        check(bool(torch.isfinite(loss)),'Nonfinite fitting objective.')
        loss.backward();return loss
    with torch.enable_grad(): opt.step(closure)
    final=float(binomial_deviance(model(),y,n).detach())
    check(final<=initial+1e-9,'Optimizer increased objective beyond tolerance.')
    opt.zero_grad();loss=1e4*binomial_deviance(model(),y,n);loss.backward()
    gradient=max(float(p.grad.abs().max()) for p in model.parameters() if p.grad is not None)
    state=next(iter(opt.state.values()));iterations=int(state.get('n_iter',0))
    with torch.no_grad():
        pred=model();w,_,A=model.core()
        check(bool(torch.isfinite(pred).all()) and float(pred.abs().max())<=1+1e-8,'Invalid probabilities.')
        check(float(torch.linalg.eigvalsh(A).abs().max())<=1+1e-8,'Invalid energy bound.')
    return {'initial_deviance':initial,'final_deviance':final,'iterations':iterations,
            'iteration_cap_reached':iterations>=max_steps,'max_steps':max_steps,
            'fresh_scaled_gradient_max':gradient,'closure_calls':calls,
            'seconds':time.perf_counter()-clock,'model':snapshot(model),
            'global_optimum_certified':False}


def select_by_loss(entries):
    return min(range(len(entries)),key=lambda i: entries[i]['final_deviance'])


def audit_tests():
    layout=SettingLayout([0,1,-1,2,-2],torch.device('cpu'))
    saved={'phases':[-.5,.7], 'weights':[.4,.6],
           'energy_real':[[-.991,0.],[0.,.993]], 'energy_imag':[[0.,0.],[0.,0.]]}
    d=restore(layout,saved,True);g=restore(layout,saved,False)
    error=float((d()-g()).abs().max().detach())
    check(error<1e-11,'Diagonal embedding is not nested in general model.')
    check(select_by_loss([{'final_deviance':.3},{'final_deviance':.1}])==1,'Likelihood selection failed.')
    n=torch.full((layout.nsettings,),10000,dtype=torch.int64)
    y=d().detach();fit=fit_audit(d,y,n,3)
    check(fit['final_deviance']<1e-10,'Exact synthetic fit test failed.')
    return {'snapshot_embedding_max_error':error,'likelihood_selection_only':True,
            'noiseless_deviance':fit['final_deviance']}


def read_curves(zf, U, B, seed):
    name=f'curves_U{U:g}_B{B}_seed{seed}.csv'
    rows=list(csv.DictReader(io.StringIO(zf.read(name).decode())))
    return {key:torch.tensor([float(r[key]) for r in rows],dtype=RDTYPE) for key in rows[0]}


def execute(args):
    import fcntl
    torch.set_num_threads(args.threads)
    source=args.input.expanduser().resolve()
    check(source.is_file(),'Girdi ZIP bulunamadi: '+str(source))
    root=args.out.expanduser().resolve();root.mkdir(parents=True,exist_ok=True)
    lock=(root/'.lock').open('w')
    try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise RuntimeError('Bu cikti klasorunde baska bir denetim calisiyor.')
    def log(message):
        print(message,flush=True)
        with (root/'run.log').open('a',encoding='utf-8') as fh:fh.write(message+'\n')
    signature=hashlib.sha256(source.read_bytes()).hexdigest()
    with zipfile.ZipFile(source) as zf:
        check(zf.testzip() is None,'Girdi ZIP CRC hatasi.')
        config=json.loads(zf.read('config.json'));details=json.loads(zf.read('details.json'))
        check(config['L']==6 and config['suite']=='validation','Expected experiment-6 validation archive.')
        cases=[(U,B,seed) for U in config['U'] for B in config['budgets'] for seed in config['seeds']]
        if args.suite=='sentinel':
            cases=[(U,B,config['seeds'][0]) for U in config['U'] for B in config['budgets']]
            stress=(5.,10**9,7013)
            if stress not in cases:cases.append(stress)
        if args.suite=='smoke':cases=[(5.,10**8,7000)]
        protocol={'version':VERSION,'input_sha256':signature,'suite':args.suite,
            'cases':cases,'extra_iterations':args.steps,'starts':args.starts,'fixed_original_ranks':True,
            'selection':'minimum combined-measurement deviance, NOT true spectral error',
            'perturbation':{'phase_sd':.015,'logit_sd':.03,'energy_parameter_sd':.015},
            'general_from_diagonal':'nested start at the continued diagonal rank; not rank-matched with old general',
            'zero_new_shots':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        blob=json.dumps(protocol,sort_keys=True).encode();phash=hashlib.sha256(blob).hexdigest()
        if (root/'protocol.json').exists():
            old=json.loads((root/'protocol.json').read_text())
            check(old['protocol_sha256']==phash,'Protocol degisti: yeni bir --out klasoru secin.')
        dump_json(root/'protocol.json',dict(protocol,protocol_sha256=phash))
        dump_json(root/'environment.json',{'torch':str(torch.__version__),'python':sys.version,
                  'machine':platform.machine(),'device':'cpu','threads':args.threads})
        tests=audit_tests();dump_json(root/'self_tests.json',tests)
        log('Dogrulama: PASS; yalniz kayitli olcumler, yeni olcum yok.')
        log(f'Plan: {len(cases)} kosul; model basina {args.starts} baslangic, en fazla {args.steps} EK iterasyon.')
        checkpoints=root/'checkpoints';checkpoints.mkdir(exist_ok=True)
        curvesdir=root/'curves';curvesdir.mkdir(exist_ok=True)
        allrows=[];clock=time.perf_counter();totalbranches=0
        for ci,(U,B,seed) in enumerate(cases,1):
            key=f'U{U:g}_B{B}_seed{seed}';old=details[key]
            results=[]
            log(f'[{ci}/{len(cases)}] {key}')
            for bid in (0,1):
                cp=checkpoints/f'{key}_branch{bid}.json'
                raw=json.loads(zf.read(f'raw_{key}_branch{bid}.json'))
                layout=SettingLayout(raw['q'],torch.device('cpu'))
                check([list(k) for k in layout.keys]==raw['keys'],'Measurement layout mismatch.')
                yt=torch.tensor(raw['observed_train'],dtype=RDTYPE);yv=torch.tensor(raw['observed_validation'],dtype=RDTYPE)
                ct=torch.tensor(raw['counts_train'],dtype=torch.int64);cv=torch.tensor(raw['counts_validation'],dtype=torch.int64)
                n=ct+cv;y=(ct*yt+cv*yv)/n
                if cp.exists():
                    branchresult=json.loads(cp.read_text())
                    check(branchresult['protocol_sha256']==phash,'Checkpoint protocol mismatch.')
                    log(f'  dal={bid}: kayitli tamam, atlandi.')
                else:
                    branchresult={'protocol_sha256':phash,'models':{}}
                    for diagonal,name in ((True,'diagonal'),(False,'general')):
                        saved=old['latent_diagonal_cv' if diagonal else 'latent_joint_cv'][bid]['model']
                        base=restore(layout,saved,diagonal)
                        baseline_loss=float(binomial_deviance(base(),y,n).detach())
                        entries=[{'model':saved,'final_deviance':baseline_loss,'start':'original_snapshot',
                                  'iterations':0,'seconds':0.}]
                        for start in range(args.starts):
                            model=restore(layout,saved,diagonal)
                            if start:perturb(model,f'{key}|{bid}|{name}|{start}')
                            fit=fit_audit(model,y,n,args.steps);fit['start']=f'continuation_{start}'
                            entries.append(fit)
                        winner=select_by_loss(entries)
                        branchresult['models'][name]={'rank':len(saved['weights']),'fits':entries,
                            'winner':winner,'selected':entries[winner], 'old_deviance':baseline_loss}
                        log(f'  dal={bid} {name}: kayip {baseline_loss:.6g} -> {entries[winner]["final_deviance"]:.6g}')
                    diagfit=branchresult['models']['diagonal']['selected']
                    nested=restore(layout,diagfit['model'],False)
                    fit=fit_audit(nested,y,n,args.steps);fit['start']='continued_diagonal_embedding'
                    branchresult['models']['general_nested']={'rank':len(diagfit['model']['weights']),
                        'fits':[dict(diagfit,start='diagonal_embedding'),fit],
                        'winner':0 if diagfit['final_deviance']<=fit['final_deviance'] else 1}
                    winner=branchresult['models']['general_nested']['winner']
                    branchresult['models']['general_nested']['selected']=branchresult['models']['general_nested']['fits'][winner]
                    log(f'  dal={bid} general_nested: kayip {diagfit["final_deviance"]:.6g} -> {branchresult["models"]["general_nested"]["selected"]["final_deviance"]:.6g}')
                    dump_json(cp,branchresult)
                results.append((branchresult,raw['info'],layout));totalbranches+=1
            # Evaluation truth is opened ONLY after training and selection.
            curves=read_curves(zf,U,B,seed);omega=curves['omega'];z=omega+.2j
            truth=curves['exact'];mass=float(integral(truth,omega))
            spectra={'raw_cutoff':curves['raw_cutoff'],'diagonal_old':curves['latent_diagonal_cv'],
                     'general_old':curves['latent_joint_cv']}
            for name in ('diagonal','general','general_nested'):
                greens=[]
                for result,info,layout in results:
                    model=restore(layout,result['models'][name]['selected']['model'],name=='diagonal')
                    with torch.no_grad():greens.append(model.green(info,z))
                spectra[name+'_extended']=-sum(greens).imag/math.pi
            for method,spec in spectra.items():
                check(bool(torch.isfinite(spec).all()) and float(spec.min())>=-1e-8,'Invalid spectrum.')
                allrows.append({'U':U,'budget':B,'seed':seed,'method':method,
                    'relative_L1_window':float(integral(abs(spec-truth),omega))/mass,
                    'posthoc_stress':seed==7013 and U==5 and B==10**9})
            outcurves=[{'omega':float(omega[i]),**{k:float(v[i]) for k,v in spectra.items()}} for i in range(len(omega))]
            write_csv(curvesdir/f'{key}.csv',outcurves)
            write_csv(root/'metrics.csv',allrows)
            log('  HATA: '+'; '.join(f'{r["method"]}=%{100*r["relative_L1_window"]:.3f}' for r in allrows[-len(spectra):]))
        dump_json(root/'summary.json',{'status':'PASS','conditions_completed':len(cases),'branches':totalbranches,
            'protocol_sha256':phash,'current_session_seconds':time.perf_counter()-clock,
            'interpretation':'post-hoc fixed-rank optimization diagnostic; no global convergence or new validation claim'})
        log(f'SONUC: PASS — {len(cases)}/{len(cases)} kosul tamam; yakinssama garantisi DEGIL.')
    archive=root.parent/(root.name+'_rapor.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as out:
        for path in sorted(root.rglob('*')):
            if path.is_file() and path.name!='.lock':out.write(path,path.relative_to(root))
        out.write(Path(__file__),'audit_script.py')
    log('RAPOR_ZIP: '+str(archive))


def write_csv(path, rows):
    tmp=path.with_suffix('.csv.tmp')
    with tmp.open('w',newline='',encoding='utf-8') as fh:
        writer=csv.DictWriter(fh,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    tmp.replace(path)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True,help='Completed experiment-6 ZIP (not Python code).')
    p.add_argument('--out',type=Path,default=Path.home()/'spektrum_deney7')
    p.add_argument('--suite',choices=('smoke','sentinel','full'),default='full')
    p.add_argument('--steps',type=int,default=1400)
    p.add_argument('--starts',type=int,default=2)
    p.add_argument('--threads',type=int,default=2)
    args=p.parse_args()
    if not 1<=args.threads<=32:p.error('threads must be in 1..32')
    if not 1<=args.starts<=10:p.error('starts must be in 1..10')
    if not 1<=args.steps<=10000:p.error('steps must be in 1..10000')
    try:execute(args)
    except (Exception,KeyboardInterrupt) as exc:
        print('\nHATA: '+str(exc),file=sys.stderr);traceback.print_exc();return 1
    return 0

if __name__=='__main__':raise SystemExit(main())
