#!/usr/bin/env python3
"""Experiment 5: fixed-circuit, pilot-guided allocation of spectral measurements.

Python 3.10+, PyTorch only. No network, installation, sudo or modifications to
previous files. CUDA initialization and index handling are inherited from the
already-working experiment-4 kernel. New GPU execution still needs testing.

This is a CLASSICAL simulation of exact binomial +/-1 measurement statistics.
No novel quantum algorithm, quantum hardware run, rigorous error certificate,
publication readiness or general speedup is claimed.

Development: L6/U=2,4,8, 20 seeds. Validation: L6/U=3,6, 30 new seeds.
All settings are logged before benchmarks. The validation suite must not be
repeatedly retuned and still called held-out. Both use total B=1e7,1e8,1e9.
Circuit layouts: prefix24, prefix16, and fixed spread16 from experiment 4.

20% pilot, independent production, 20% uniform allocation floor. Allocator
sees only measured data and analytic metadata. Exact spectra are evaluator
only. Pilot costs, all Gram lag measurements, and all Hbar matrix elements
are charged. Independent branches are both charged. No free candidate search.

The new direction tested here is SPECTRUM-SENSITIVE SHOT ALLOCATION, not a
new circuit-selection policy. Adaptive measurement for subspace methods is
already established. Relevant primary literature:
https://arxiv.org/abs/2311.07893
https://arxiv.org/abs/2409.02504
https://arxiv.org/abs/2205.00094

The risk approximation freezes the pilot subspace and differentiates the
full Green function, including shared S-lag noise and f=beta*S[:,0]. Hard
rank changes are not differentiated. A fixed heuristic truncation remains.
The reported gate-work proxy is NOT compiled native two-qubit cost.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import random
import statistics
import sys
import time
import traceback
import uuid
import zipfile
from datetime import datetime, timezone
from itertools import combinations
from pathlib import Path
from typing import Any

try:
    import torch
except ImportError as exc:
    raise SystemExit("PyTorch bulunamadi. GPU kontrolunu yaptigin Python ile calistir.") from exc

VERSION = "0.5.0-allocation-audit"
CDTYPE = torch.complex128
RDTYPE = torch.float64


def integral(y: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
    return torch.sum((y[..., 1:] + y[..., :-1]) * (x[1:] - x[:-1]) * 0.5, dim=-1)


def dump_json(path: Path, value: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def check(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def ladder(bits: int, orbital: int, create: bool) -> tuple[int, int] | None:
    if bool((bits >> orbital) & 1) == create:
        return None
    sign = -1 if (bits & ((1 << orbital) - 1)).bit_count() % 2 else 1
    return bits ^ (1 << orbital), sign


def basis(L: int, nup: int, ndown: int) -> list[int]:
    return [sum(1 << j for j in u) + sum(1 << (L + j) for j in d)
            for u in combinations(range(L), nup)
            for d in combinations(range(L), ndown)]


def hamiltonian(L: int, nup: int, ndown: int, U: float,
                device: torch.device) -> tuple[torch.Tensor, list[int]]:
    """Open chain, t=1, mu=U/2. Spin-up orbitals precede spin-down."""
    bas = basis(L, nup, ndown)
    pos = {b: j for j, b in enumerate(bas)}
    H = torch.zeros((len(bas), len(bas)), dtype=RDTYPE, device="cpu")
    for j, bits in enumerate(bas):
        H[j, j] = U * sum(((bits >> k) & 1) * ((bits >> (L+k)) & 1)
                          for k in range(L)) - U * (nup + ndown) / 2
        for spin in (0, L):
            for k in range(L-1):
                for p, q in ((spin+k, spin+k+1), (spin+k+1, spin+k)):
                    a = ladder(bits, q, False)
                    b = ladder(a[0], p, True) if a else None
                    if b:
                        H[pos[b[0]], j] -= a[1] * b[1]
    check(float(torch.max(torch.abs(H-H.T))) < 1e-12, "Hamiltonian Hermitik degil.")
    return H.to(device=device, dtype=CDTYPE), bas


def build_problem(L: int, U: float, device: torch.device) -> dict[str, Any]:
    n, orbital = L // 2, L // 2 - 1
    H, bas = hamiltonian(L, n, n, U, device)
    ev, vec = torch.linalg.eigh(H)
    E0, ground = float(ev[0]), vec[:, 0]
    branches = []
    for create in (True, False):
        Hb, bb = hamiltonian(L, n + (1 if create else -1), n, U, device)
        b = torch.zeros(len(bb), dtype=CDTYPE, device=device)
        ix = {bits: j for j, bits in enumerate(bb)}
        for j, bits in enumerate(bas):
            out = ladder(bits, orbital, create)
            if out is not None:
                b[ix[out[0]]] = out[1] * ground[j]
        K = Hb - E0 * torch.eye(len(bb), dtype=CDTYPE, device=device)
        if not create:
            K = -K
        branches.append({"name": "add" if create else "remove", "K": K,
                         "b": b, "basis": bb, "energy_sign": 1 if create else -1})
    mass = sum(float(torch.vdot(q["b"], q["b"]).real) for q in branches)
    check(abs(mass-1.0) < 1e-10, "Elektron ekleme/cikarma agirliklari 1 etmiyor.")
    return {"L": L, "U": U, "E0": E0, "physical_E0": E0 + U*L/2,
            "orbital": orbital, "source_mass": mass, "ground_dimension": len(bas),
            "branches": branches}


def green(K: torch.Tensor, b: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
    ev, vec = torch.linalg.eigh((K + K.mH) * 0.5)
    weight = torch.abs(vec.mH @ b).square()
    return torch.sum(weight[:, None] / (z[None, :] - ev[:, None]), dim=0)


def make_gates(L: int, bas: list[int], device: torch.device) -> list[dict[str, Any]]:
    pos = {bits: j for j, bits in enumerate(bas)}
    gates: list[dict[str, Any]] = []
    for spin in (0, 1):
        for site in range(L-1):
            p, q = spin*L+site, spin*L+site+1
            aidx, bidx, signs = [], [], []
            for col, bits in enumerate(bas):
                a = ladder(bits, q, False)
                b = ladder(a[0], p, True) if a else None
                if b:
                    aidx.append(col); bidx.append(pos[b[0]]); signs.append(a[1]*b[1])
            gates.append({"kind": "hop", "label": ["hop", spin, site],
                          "a": torch.tensor(aidx, dtype=torch.long, device=device),
                          "b": torch.tensor(bidx, dtype=torch.long, device=device),
                          "sign": torch.tensor(signs, dtype=RDTYPE, device=device)})
    for orbital in range(2*L):
        mask = [j for j, bits in enumerate(bas) if (bits >> orbital) & 1]
        gates.append({"kind": "phase", "label": ["occupation_phase", orbital],
                      "mask": torch.tensor(mask, dtype=torch.long, device=device)})
    for site in range(L):
        mask = [j for j, bits in enumerate(bas) if ((bits >> site)&1) and ((bits >> (L+site))&1)]
        gates.append({"kind": "phase", "label": ["double_occupation_phase", site],
                      "mask": torch.tensor(mask, dtype=torch.long, device=device)})
    return gates


def apply_gate(v: torch.Tensor, gate: dict[str, Any], theta: float) -> torch.Tensor:
    out = v.clone()
    if gate["kind"] == "hop":
        a, b, s = gate["a"], gate["b"], gate["sign"]
        out[a] = math.cos(theta)*v[a] - 1j*math.sin(theta)*s*v[b]
        out[b] = math.cos(theta)*v[b] - 1j*math.sin(theta)*s*v[a]
    else:
        out[gate["mask"]] *= complex(math.cos(theta), -math.sin(theta))
    return out




def compressed(C: torch.Tensor, data: dict[str, Any], z: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    T = C.mH @ data["T"] @ C
    f = C.mH @ data["f"]
    ev, vec = torch.linalg.eigh((T+T.mH)*0.5)
    c = vec @ ((vec.mH @ f)[:, None] / (z[None, :]-ev[:, None]))
    return torch.sum(f.conj()[:, None]*c, dim=0), c




def krylov_history(K: torch.Tensor, b: torch.Tensor, mmax: int) -> list[torch.Tensor]:
    Q = (b/torch.linalg.vector_norm(b))[:, None]
    history = []
    for _ in range(mmax):
        history.append(Q.clone())
        if Q.shape[1] >= mmax:
            break
        v = K @ Q[:, -1]
        for _pass in range(2):
            v = v-Q @ (Q.mH @ v)
        norm = float(torch.linalg.vector_norm(v))
        if norm < 1e-10:
            break
        Q = torch.cat((Q, (v/norm)[:, None]), dim=1)
    return history


def self_tests(device: torch.device) -> dict[str, float]:
    out: dict[str, float] = {}
    p = build_problem(4, 4.0, device)
    out["L4_U4_physical_ground_energy_error"] = abs(p["physical_E0"]+1.953145308684558)
    check(out["L4_U4_physical_ground_energy_error"] < 1e-10, "Referans enerji testi basarisiz.")
    omega = torch.linspace(-12, 12, 241, device=device, dtype=RDTYPE)
    z = omega+0.2j
    free = build_problem(4, 0.0, device)
    exact = sum(green(b["K"], b["b"], z) for b in free["branches"])
    k = torch.arange(1, 5, dtype=RDTYPE, device=device)*math.pi/5
    weights = 2/5*torch.sin(k*(free["orbital"]+1)).square()
    analytic = torch.sum(weights[:, None]/(z[None, :]+2*torch.cos(k)[:, None]), dim=0)
    out["noninteracting_green_max_error"] = float(torch.max(torch.abs(exact-analytic)))
    check(out["noninteracting_green_max_error"] < 1e-9, "U=0 analitik spektrum testi basarisiz.")
    branch = p["branches"][0]
    K, b = branch["K"], branch["b"]
    Q = krylov_history(K, b, 4)[-1]
    zz = torch.tensor(0.7+0.2j, dtype=CDTYPE, device=device)
    T, f = Q.mH @ K @ Q, Q.mH @ b
    c = torch.linalg.solve(zz*torch.eye(4, device=device, dtype=CDTYPE)-T, f)
    r = b-zz*(Q@c)+K@(Q@c)
    F = (K@Q).mH@(K@Q)
    identity = torch.vdot(c, (F-T@T)@c).real
    out["residual_identity_abs_error"] = float(torch.abs(torch.vdot(r, r).real-identity))
    check(out["residual_identity_abs_error"] < 1e-9, "Artik ozdesligi testi basarisiz.")
    # Complete tiny-sector projection must reproduce the full reference.
    I = torch.eye(len(b), dtype=CDTYPE, device=device)
    reference = green(K, b, z)
    projected, _ = compressed(I, {"T": K, "f": b}, z)
    out["full_projection_max_error"] = float(torch.max(torch.abs(reference-projected)))
    check(out["full_projection_max_error"] < 1e-9, "Tam altuzay testi basarisiz.")
    if device.type == "cuda":
        cpu = green(K.cpu(), b.cpu(), z.cpu())
        out["cpu_cuda_green_max_difference"] = float(torch.max(torch.abs(cpu-reference.cpu())))
        check(out["cpu_cuda_green_max_difference"] < 1e-8, "CPU/CUDA tutarlilik testi basarisiz.")
    return out


def csv_write(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)



def get_device(name: str) -> torch.device:
    device = torch.device(name)
    if device.type == "cuda":
        check(torch.cuda.is_available(), "CUDA kullanilamiyor; CPU'ya sessizce gecilmedi.")
        torch.cuda.init()
        index = device.index if device.index is not None else 0
        check(0 <= index < torch.cuda.device_count(), "GPU indeksi gecersiz.")
        torch.cuda.set_device(index)
        device = torch.device("cuda", index)
        torch.empty(1, device=device)  # Initialize the allocator before optional telemetry.
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    elif device.type != "cpu":
        raise ValueError("Bu deney yalniz cpu veya cuda[:index] kabul eder.")
    return device


def environment(device: torch.device) -> dict[str, Any]:
    info = {"python": sys.version, "platform": platform.platform(),
            "torch": str(torch.__version__), "cuda_build": torch.version.cuda,
            "device": str(device), "dtype": "complex128", "cpu_threads": torch.get_num_threads()}
    if device.type == "cuda":
        info["gpu"] = torch.cuda.get_device_name(device.index)
        try:
            torch.cuda.reset_peak_memory_stats(device.index)
            free, total = torch.cuda.mem_get_info(device.index)
            info.update(reported_free_bytes=free, reported_total_bytes=total)
        except (RuntimeError, ValueError) as exc:
            info["optional_memory_telemetry_warning"] = str(exc)
    return info



def product_step(v: torch.Tensor, groups: tuple, U: float, dt: float,
                 branch_sign: int, rng: random.Random | None = None) -> torch.Tensor:
    """Second-order even/odd/onsite symmetric product, up to global phase.

    H=-sum hopping + U sum double occupation. Chemical potential and E0
    contribute only an irrelevant global phase in each fixed-number sector.
    rng!=None independently flips signs of each scheduled elementary angle.
    """
    even, odd, onsite = groups
    h = branch_sign * dt
    for gates, angle in ((even, -h/2), (odd, -h/2), (onsite, U*h),
                         (odd, -h/2), (even, -h/2)):
        for gate in gates:
            a = angle if rng is None else angle * rng.choice((-1, 1))
            v = apply_gate(v, gate, a)
    return v


def product_groups(L: int, branch: dict[str, Any]) -> tuple:
    gates = make_gates(L, branch['basis'], branch['b'].device)
    even = [g for g in gates if g['kind'] == 'hop' and g['label'][2] % 2 == 0]
    odd = [g for g in gates if g['kind'] == 'hop' and g['label'][2] % 2 == 1]
    onsite = [g for g in gates if g['label'][0] == 'double_occupation_phase']
    return even, odd, onsite


def fixed_time_pool(L: int, U: float, branch: dict[str, Any], size: int,
                    spacing: float, step: float | None,
                    scrambled_seed: int | None = None) -> tuple[dict, list, torch.Tensor]:
    b = branch['b'] / torch.linalg.vector_norm(branch['b'])
    states, recipes = [b], [{'time': 0., 'steps': 0, 'scheduled_rotations': 0}]
    exact = step is None
    if exact:
        check(scrambled_seed is None, 'Exact-time scrambled pool is undefined.')
        ev, vec = torch.linalg.eigh(branch['K'])
        coef = vec.mH @ b
        rotations_per_step = 0
    else:
        ns = round(spacing/step)
        check(ns >= 1 and abs(ns*step-spacing) < 1e-12, 'Spacing must be a multiple of product step.')
        groups = product_groups(L, branch)
        rotations_per_step = 2*len(groups[0]) + 2*len(groups[1]) + len(groups[2])
        states_by_sign = {1: b.clone(), -1: b.clone()}
        rngs = {sgn: random.Random(131071*scrambled_seed + (17 if sgn == 1 else 29))
                if scrambled_seed is not None else None for sgn in (1, -1)}
    k = 1
    while len(states) < size:
        for sgn in (1, -1):
            if len(states) >= size:
                break
            time_value = sgn*k*spacing
            if exact:
                v = vec @ (torch.exp(-1j*ev*time_value) * coef)
                nsteps, nrot = None, None
            else:
                v = states_by_sign[sgn]
                for _ in range(ns):
                    v = product_step(v, groups, U, sgn*step, branch['energy_sign'], rngs[sgn])
                states_by_sign[sgn] = v
                nsteps, nrot = k*ns, k*ns*rotations_per_step
            states.append(v.clone())
            recipes.append({'time': time_value, 'steps': nsteps,
                            'scheduled_rotations': nrot, 'scrambled_seed': scrambled_seed})
        k += 1
    P = torch.stack(states, dim=1)
    S, T = P.mH @ P, P.mH @ (branch['K'] @ P)
    check(float(torch.max(torch.abs(S.diag().real-1))) < 1e-9, 'Time pool norm drift.')
    data = {'S': (S+S.mH)/2, 'T': (T+T.mH)/2, 'f': P.mH @ branch['b']}
    return data, recipes, P


def fixed_green(data: dict, z: torch.Tensor, size: int,
                gram_rtol: float) -> tuple[torch.Tensor, dict]:
    """Matrix-only projected solve. Keep the exact source, then truncate
    the source-orthogonal Gram matrix. No full states/eigen-spectrum needed.
    Every input circuit counts as acquired even when numerical rank is lower.
    """
    S = data['S'][:size, :size]
    T = data['T'][:size, :size]
    f = data['f'][:size]
    s0 = float(S[0, 0].real)
    check(s0 > .99, 'Invalid normalized source.')
    C0 = torch.zeros((size, 1), dtype=CDTYPE, device=S.device)
    C0[0, 0] = 1/math.sqrt(s0)
    R = S[1:, 1:] - S[1:, :1] @ S[:1, 1:] / s0
    vals, vecs = torch.linalg.eigh((R+R.mH)/2)
    vmax = max(float(vals[-1]), 0.) if vals.numel() else 0.
    check(not vals.numel() or float(vals[0]) > -1e-9*max(1., vmax), 'Nonpositive Gram matrix beyond rounding.')
    keep = vals > max(vmax*gram_rtol, 1e-14)
    if bool(keep.any()):
        D = vecs[:, keep] / torch.sqrt(vals[keep])[None, :]
        C = torch.cat((C0, torch.cat((-S[:1, 1:] @ D / s0, D), dim=0)), dim=1)
        retained_condition = vmax/float(vals[keep][0])
    else:
        C, retained_condition = C0, 1.
    # Symmetric metric correction limits cancellation error from whitening.
    M = C.mH @ S @ C
    me, mv = torch.linalg.eigh((M+M.mH)/2)
    check(float(me.min()) > .9 and float(me.max()) < 1.1, 'Gram normalization unstable.')
    C = C @ ((mv*me.rsqrt()[None, :]) @ mv.mH)
    defect = float(torch.max(torch.abs(C.mH @ S @ C - torch.eye(C.shape[1], dtype=CDTYPE, device=S.device))))
    check(defect < 2e-6, f'Gram orthogonality defect: {defect:g}')
    Tp, fp = C.mH @ T @ C, C.mH @ f
    G = green(Tp, fp, z)
    mass = float(torch.linalg.vector_norm(fp).square())
    expected_mass = float(torch.abs(f[0]).square()/s0)
    check(abs(mass-expected_mass) < 2e-6, 'Source mass lost in Gram truncation.')
    return G, {'input_states': size, 'retained_rank': C.shape[1],
               'source_mass': mass, 'gram_rtol': gram_rtol,
               'retained_source_orthogonal_gram_condition': retained_condition,
               'orthogonality_defect': defect}


def extra_tests(device: torch.device) -> dict:
    prob = build_problem(4, 4., device)
    br = prob['branches'][0]
    b = br['b']/torch.linalg.vector_norm(br['b'])
    groups = product_groups(4, br)
    v = product_step(b, groups, 4., .1, br['energy_sign'])
    w = product_step(v, groups, 4., -.1, br['energy_sign'])
    inverse_error = float(torch.linalg.vector_norm(w-b))
    check(inverse_error < 1e-11, 'Symmetric product inverse test failed.')
    e, V = torch.linalg.eigh(br['K'])
    target = V @ (torch.exp(-1j*.4*e)*(V.mH@b))
    errors = []
    for nsteps in (4, 8, 16):
        v = b.clone()
        for _ in range(nsteps):
            v = product_step(v, groups, 4., .4/nsteps, br['energy_sign'])
        overlap = torch.vdot(target, v)
        phase = overlap/torch.abs(overlap)
        errors.append(float(torch.linalg.vector_norm(v-target*phase)))
    check(errors[1] < errors[0]/3 and errors[2] < errors[1]/3,
          'Second-order step convergence failed.')
    omega = torch.linspace(-12, 12, 241, dtype=RDTYPE, device=device)
    z = omega+.2j
    data, rec, P = fixed_time_pool(4, 4., br, 12, .5, .125)
    G, info = fixed_green(data, z, 12, 1e-8)
    # This L4 source-orthogonal subspace is well conditioned. Independent QR
    # evaluator must agree with the matrix-only solve when no modes are dropped.
    check(info['retained_rank'] == 12, 'Unexpected rank in independent QR test.')
    Q, _ = torch.linalg.qr(P, mode='reduced')
    ref = green(Q.mH@br['K']@Q, Q.mH@br['b'], z)
    err = float(torch.max(torch.abs(ref-G)))
    check(err < 1e-6, 'Gram/independent-QR projected Green mismatch.')
    _, rec2, P2 = fixed_time_pool(4, 4., br, 12, .5, .125, 11)
    check([x['scheduled_rotations'] for x in rec] == [x['scheduled_rotations'] for x in rec2],
          'Scrambled rotation counts mismatch.')
    check(float(torch.linalg.vector_norm(P-P2)) > .1, 'Scrambling did not change states.')
    return {'symmetric_product_inverse_error': inverse_error,
            'second_order_projective_errors': errors, 'gram_vs_QR_green_max_difference': err,
            'matched_scheduled_rotation_counts': True}



POOL_SIZE = 24
SPACING = 0.5
PRODUCT_STEP = 0.125
ETA = 0.2
NOISE_CUTOFF_FACTOR = 2.0
POLICIES = [('prefix12', 12), ('prefix16', 16), ('prefix24', 24),
            ('spread16', 16), ('gram16', 16), ('spectral16', 16)]


def time_indices(n: int) -> list[int]:
    return [0] + [((j+1)//2) * (1 if j % 2 else -1) for j in range(1,n)]


def predetermined(policy: str, m: int, q: list[int]) -> list[int]:
    if policy.startswith('prefix'):
        return list(range(m))
    check(policy.startswith('spread'), 'Unknown predetermined policy.')
    ts = [round(min(q) + j*(max(q)-min(q))/(m-1)) for j in range(m)]
    if 0 not in ts:
        ts[min(range(1,m-1), key=lambda j: abs(ts[j]))] = 0
    check(len(set(ts))==m, 'Spread time grid has duplicates.')
    return [0] + [q.index(t) for t in sorted((t for t in ts if t), key=lambda x:(abs(x),-x))]


def setting_quota(policy: str, m: int, q: list[int]) -> int:
    n=len(q)
    if policy.startswith(('prefix','spread')):
        ii=predetermined(policy,m,q)
        lags={abs(q[i]-q[j]) for i in ii for j in ii if i!=j}
        return 2*len(lags)+m*m
    s_count=2*(max(q)-min(q))
    if policy.startswith('gram'):
        return s_count+m*m
    if policy.startswith('spectral'):
        # All diagonals + all off-diagonals touching m-1 selected columns.
        return s_count+n+2*n*(m-1)-m*(m-1)
    raise ValueError(policy)


class MeasurementService:
    """Exact probabilities are private simulation internals. Policies access
    only S/H query methods; every newly sampled real quantity is charged.
    H returned by hbar() is the physical Hbar matrix (not K).
    """
    def __init__(self, data: dict, branch: dict, U: float, L: int,
                 E0: float, shots: int | None, seed: int, branch_id: int,
                 q: list[int], max_settings: int):
        self.device=data['S'].device
        self.n=len(q); self.q=list(q); self.shots=shots
        self.beta=float(torch.linalg.vector_norm(branch['b']))
        self.shift=E0+U*L/4
        self.sign=branch['energy_sign']
        self.scale=2*(L-1)+U*L/4
        self.rotations_per_tick=round(SPACING/PRODUCT_STEP)*(4*(L-1)+L)
        self.max_settings=max_settings
        self._S=data['S'].detach().cpu()
        self._H=(self.sign*data['T']+self.shift*data['S']).detach().cpu()
        self._lag={}
        for i in range(self.n):
            for j in range(self.n):
                d=q[j]-q[i]
                if d>0:
                    val=complex(self._S[i,j])
                    if d in self._lag:
                        check(abs(val-self._lag[d])<1e-8, 'Unitary overlap lag identity failed.')
                    else:
                        self._lag[d]=val
        check(float(self._H.abs().max()) <= self.scale+1e-8, 'Random-Pauli normalization failed.')
        self._cache={}; self.count_S=0; self.count_H=0; self.rotation_proxy=0
        self._seed_text=f'{L}|{U:.8g}|{branch_id}|{seed}|{shots}'

    def _sample(self, key: tuple, mean: float, rotations: int) -> float:
        if key in self._cache:
            return self._cache[key]
        check(abs(mean)<=1+1e-8, 'Hadamard outcome mean outside [-1,1].')
        mean=max(-1.,min(1.,mean))
        if self.shots is None:
            result=mean
        else:
            digest=hashlib.sha256((self._seed_text+'|'+repr(key)).encode()).digest()
            gen=torch.Generator(device='cpu').manual_seed(int.from_bytes(digest[:8],'little')%(2**63-1))
            hits=float(torch.binomial(torch.tensor(float(self.shots),dtype=RDTYPE),
                        torch.tensor((1+mean)/2,dtype=RDTYPE),generator=gen))
            result=2*hits/self.shots-1
        self._cache[key]=result
        if key[0]=='S': self.count_S+=1
        else: self.count_H+=1
        self.rotation_proxy+=rotations
        check(len(self._cache)<=self.max_settings, 'Acquisition exceeded predeclared budget quota.')
        return result

    def overlap(self, i: int, j: int) -> complex:
        d=self.q[j]-self.q[i]
        if not d: return 1+0j
        a=abs(d); true=self._lag[a]
        cost=a*self.rotations_per_tick
        r=self._sample(('S',a,'R'),true.real,cost)
        im=self._sample(('S',a,'I'),true.imag,cost)
        val=complex(r,im)
        return val if d>0 else val.conjugate()

    def hbar(self, i: int, j: int) -> complex:
        if i>j: return self.hbar(j,i).conjugate()
        true=complex(self._H[i,j])/self.scale
        # Conservative independent-preparation proxy, not compiled gate count.
        cost=self.rotations_per_tick*(abs(self.q[i])+abs(self.q[j]))
        r=self._sample(('H',i,j,'R'),true.real,cost)
        im=0. if i==j else self._sample(('H',i,j,'I'),true.imag,cost)
        return self.scale*complex(r,im)

    def gram(self, indices: list[int]) -> torch.Tensor:
        return torch.tensor([[self.overlap(i,j) for j in indices] for i in indices],
                            dtype=CDTYPE,device=self.device)

    def matrices(self, indices: list[int]) -> tuple[torch.Tensor,torch.Tensor]:
        S=self.gram(indices)
        H=torch.tensor([[self.hbar(i,j) for j in indices] for i in indices],
                       dtype=CDTYPE,device=self.device)
        return S,self.sign*(H-self.shift*S)

    def report(self) -> dict:
        repeats=self.shots or 0
        return {'S_real_settings':self.count_S,'H_real_settings':self.count_H,
                'total_real_settings':len(self._cache),
                'actual_shots':len(self._cache)*repeats,
                'shot_weighted_rotation_proxy':self.rotation_proxy*repeats,
                'per_setting_shots':self.shots,'quota_per_branch':self.max_settings}


def whiten_source(S: torch.Tensor, shots: int | None) -> tuple[torch.Tensor,dict]:
    """Keep the source exactly in the retained span. Drop nonpositive/too-small
    modes of the noisy source-orthogonal Gram matrix. This is regularization,
    NOT a certificate that its projected spectrum is close to the true one.
    """
    m=S.shape[0]
    C0=torch.zeros((m,1),dtype=CDTYPE,device=S.device); C0[0,0]=1
    R=S[1:,1:]-S[1:,:1]@S[:1,1:]
    vals,vecs=torch.linalg.eigh((R+R.mH)/2)
    vmax=max(float(vals.max()),0.) if vals.numel() else 0.
    noise=0. if shots is None else NOISE_CUTOFF_FACTOR*m/math.sqrt(shots)
    threshold=max(vmax*1e-8,noise,1e-14)
    keep=vals>threshold
    if bool(keep.any()):
        D=vecs[:,keep]/torch.sqrt(vals[keep])[None,:]
        C=torch.cat((C0,torch.cat((-S[:1,1:]@D,D),dim=0)),dim=1)
        condition=vmax/float(vals[keep].min())
    else: C=C0; condition=1.
    defect=float((C.mH@S@C-torch.eye(C.shape[1],dtype=CDTYPE,device=S.device)).abs().max())
    check(defect<5e-5,'Regularized Gram normalization unstable.')
    return C,{'rank':C.shape[1],'cutoff':threshold,'negative_gram_modes':int((vals < -1e-10).sum()),
              'orthogonality_defect':defect,'retained_condition':condition}


def project_measured(S:torch.Tensor,T:torch.Tensor,beta:float,z:torch.Tensor,
                     shots:int|None) -> tuple[torch.Tensor,dict]:
    C,info=whiten_source(S,shots)
    f=beta*S[:,0]
    Tp=C.mH@T@C; fp=C.mH@f
    G=green(Tp,fp,z)
    mass=float(torch.linalg.vector_norm(fp).square())
    check(abs(mass-beta*beta)<2e-5,'Measured source mass inconsistency.')
    info['source_mass']=mass
    return G,info


def choose_circuits(service:MeasurementService,policy:str,m:int,omega:torch.Tensor) -> tuple[list[int],list]:
    if policy.startswith(('prefix','spread')):
        return predetermined(policy,m,service.q),[]
    n=service.n; S=service.gram(list(range(n)))
    selected=[0]; history=[]; z=omega+1j*ETA
    diagH=None
    if policy.startswith('spectral'):
        diagH=torch.tensor([service.hbar(i,i).real for i in range(n)],dtype=RDTYPE,device=S.device)
    while len(selected)<m:
        ix=torch.tensor(selected,dtype=torch.long,device=S.device)
        Ssub=S[ix[:,None],ix[None,:]]
        C,info=whiten_source(Ssub,service.shots)
        overlaps=C.mH@S[ix,:]
        innovation=1-overlaps.abs().square().sum(dim=0)
        valid=torch.ones(n,dtype=torch.bool,device=S.device); valid[ix]=False
        if policy.startswith('gram'):
            scores=innovation.clone()
        else:
            Hrows=torch.tensor([[service.hbar(i,j) for j in range(n)] for i in selected],
                               dtype=CDTYPE,device=S.device)
            Trows=service.sign*(Hrows-service.shift*S[ix,:])
            Tsub=Trows[:,ix]
            Tp=C.mH@Tsub@C
            fp=C.mH@(service.beta*Ssub[:,0])
            valid=valid&(innovation>1e-7)
            ids=torch.nonzero(valid).flatten()
            scores=torch.full((n,),-torch.inf,dtype=RDTYPE,device=S.device)
            if ids.numel():
                d=innovation[ids]; B=overlaps[:,ids]; cross=C.mH@Trows[:,ids]
                h=(cross-Tp@B)/torch.sqrt(d)[None,:]
                diagT=service.sign*(diagH[ids]-service.shift)
                a=(diagT-2*(B.conj()*cross).sum(dim=0).real+
                   (B.conj()*(Tp@B)).sum(dim=0).real)/d
                ev,V=torch.linalg.eigh((Tp+Tp.mH)/2)
                hh=V.mH@h; aa=V.mH@fp; den=z[None,:]-ev[:,None]
                left=(aa.conj()[:,None,None]*hh[:,:,None]/den[:,None,:]).sum(dim=0)
                right=(hh.conj()[:,:,None]*aa[:,None,None]/den[:,None,:]).sum(dim=0)
                schur=z[None,:]-a[:,None]-(hh.abs().square()[:,:,None]/den[:,None,:]).sum(dim=0)
                delta=left*right/schur
                scores[ids]=integral(delta.imag.abs()/math.pi,omega)
            else:
                # Explicitly record fallback, not an invisible numerical failure.
                scores=innovation.clone(); valid=torch.ones(n,dtype=torch.bool,device=S.device); valid[ix]=False
                info['fallback']='no_positive_innovation; Gram diversity fallback'
        scores[~valid]=-torch.inf
        j=int(torch.argmax(scores))
        check(math.isfinite(float(scores[j])),'No finite candidate score.')
        history.append({'selected_before':selected.copy(),'rank':info['rank'],
                        'chosen':j,'score':float(scores[j]),'fallback':info.get('fallback')})
        selected.append(j)
    return selected,history


def measurement_tests(device:torch.device) -> dict:
    prob=build_problem(4,4.,device); br=prob['branches'][0]
    data,rec,P=fixed_time_pool(4,4.,br,24,.5,.125)
    # Independently verify the operator actually sampled by the Pauli mixture.
    Hhop,bas=hamiltonian(4,3,2,0.,device)
    zz=torch.tensor([sum((1-2*((bits>>i)&1))*(1-2*((bits>>(4+i))&1))
                         for i in range(4)) for bits in bas],dtype=RDTYPE,device=device)
    Hbar_direct=Hhop+torch.diag(zz.to(CDTYPE))  # U/4 = 1 here.
    Hbar_from_K=br['K']+(prob['E0']+4.)*torch.eye(len(bas),dtype=CDTYPE,device=device)
    pauli_error=float((Hbar_direct-Hbar_from_K).abs().max())
    check(pauli_error<1e-10,'Sampled Pauli Hamiltonian differs from the physical operator.')
    q=time_indices(24)
    quota=setting_quota('prefix24',24,q)
    svc=MeasurementService(data,br,4.,4,prob['E0'],None,0,0,q,quota)
    S,T=svc.matrices(list(range(24)))
    check(float((S-data['S']).abs().max())<1e-8,'Overlap lag reconstruction failed.')
    check(float((T-data['T']).abs().max())<1e-8,'Hbar/K reconstruction failed.')
    check(svc.report()['total_real_settings']==quota,'Setting-accounting identity failed.')
    z=torch.linspace(-12,12,241,dtype=RDTYPE,device=device)+.2j
    g,info=project_measured(S,T,svc.beta,z,None)
    g0,_=fixed_green(data,z,24,1e-8)
    err=float((g-g0).abs().max()); check(err<1e-5,'Noiseless solver consistency failed.')
    noisy=MeasurementService(data,br,4.,4,prob['E0'],10000,11,0,q,quota)
    a=noisy.overlap(0,1); before=noisy.report()['actual_shots']
    b=noisy.overlap(1,0)
    check(abs(a-b.conjugate())<1e-14 and noisy.report()['actual_shots']==before,'Cache/Hermiticity failed.')
    gen=torch.Generator().manual_seed(123456)
    N=200; mu=.37
    draws=2*torch.binomial(torch.full((10000,),float(N),dtype=RDTYPE),
                          torch.full((10000,),(1+mu)/2,dtype=RDTYPE),generator=gen)/N-1
    var=float(draws.var(unbiased=True)); theory=(1-mu*mu)/N
    check(abs(float(draws.mean())-mu)<.005 and .9<var/theory<1.1,'Binomial mean/variance test failed.')
    # Direct Schur-complement identity, independent of the policy implementation.
    gen.manual_seed(8)
    A=torch.randn((5,5),generator=gen,dtype=RDTYPE).to(device,CDTYPE)
    A=(A+A.mH)/2; f=torch.tensor([1.,.2,.1,0.,0.],device=device,dtype=CDTYPE)
    z0=torch.tensor(.7+.2j,device=device,dtype=CDTYPE)
    M=z0*torch.eye(4,device=device,dtype=CDTYPE)-A[:4,:4]
    h=A[:4,4]; g4=torch.vdot(f[:4],torch.linalg.solve(M,f[:4]))
    delta=(f[:4].conj()@torch.linalg.solve(M,h))*(h.conj()@torch.linalg.solve(M,f[:4]))/(z0-A[4,4]-h.conj()@torch.linalg.solve(M,h))
    g5=torch.vdot(f,torch.linalg.solve(z0*torch.eye(5,device=device,dtype=CDTYPE)-A,f))
    schur_err=float(abs(g5-g4-delta)); check(schur_err<1e-10,'Schur update identity failed.')
    return {'sampled_pauli_operator_max_error':pauli_error,
            'noiseless_measured_vs_baseline_max_error':err,'settings_per_branch_24':quota,
            'binomial_mean':float(draws.mean()),'binomial_variance_ratio':var/theory,
            'schur_identity_error':schur_err,'cache_and_hermiticity':True}



# Experiment 5: no circuit search. All layouts and hyperparameters below are
# fixed before the validation suite. Rejected experiment-4 policies are not
# relabeled as successful methods.
PILOT_FRACTION = 0.20
ALLOCATION_UNIFORM_FLOOR = 0.20
VARIANCE_FLOOR = 1e-4
EXPERIMENT5_VARIANTS = [
    ('prefix24', 'uniform'),
    ('prefix24', 'fixed10'), ('prefix24', 'fixed20'),
    ('prefix24', 'fixed30'), ('prefix24', 'fixed50'),
    ('prefix24', 'pilot_control'), ('prefix24', 'adaptive'),
    ('prefix16', 'uniform'),
    ('spread16', 'uniform'), ('spread16', 'adaptive'),
]


class SettingLayout:
    """Public measurement geometry, without exact probabilities or spectra."""
    def __init__(self, q: list[int], device: torch.device):
        check(q[0] == 0 and len(set(q)) == len(q), 'Invalid source/time layout.')
        self.q = q.copy()
        self.m = len(q)
        self.keys: list[tuple] = []
        overlap_directions, h_directions, costs = [], [], []
        lags = sorted({abs(i-j) for i in q for j in q if i != j})
        for d in lags:
            for part in ('R', 'I'):
                E = torch.zeros((self.m, self.m), dtype=CDTYPE)
                for i in range(self.m):
                    for j in range(self.m):
                        if q[j]-q[i] == d:
                            E[i,j] = 1 if part == 'R' else 1j
                        elif q[j]-q[i] == -d:
                            E[i,j] = 1 if part == 'R' else -1j
                self.keys.append(('S', d, part))
                overlap_directions.append(E)
                costs.append(abs(d))
        self.ns = len(self.keys)
        for i in range(self.m):
            for j in range(i, self.m):
                for part in (('R',) if i == j else ('R', 'I')):
                    E = torch.zeros((self.m, self.m), dtype=CDTYPE)
                    E[i,j] = 1 if part == 'R' else 1j
                    E[j,i] = E[i,j].conj()
                    self.keys.append(('H', i, j, part))
                    h_directions.append(E)
                    costs.append(abs(q[i])+abs(q[j]))
        self.nsettings = len(self.keys)
        self.ES = torch.stack(overlap_directions).to(device)
        self.EH = torch.stack(h_directions).to(device)
        self.time_tick_cost = torch.tensor(costs, dtype=torch.int64)
        self.device = device

    def matrices(self, observations: torch.Tensor, info: dict) -> tuple[torch.Tensor,torch.Tensor]:
        mu = observations.to(device=self.device, dtype=CDTYPE)
        S = torch.eye(self.m, dtype=CDTYPE, device=self.device)
        S = S + torch.einsum('k,kij->ij', mu[:self.ns], self.ES)
        Hbar = info['scale'] * torch.einsum('k,kij->ij', mu[self.ns:], self.EH)
        return S, info['sign'] * (Hbar - info['shift']*S)


class SamplingBackend:
    """Private classical simulator. A policy receives sample(), not _means.

    The +/-1 normalized Hbar random-Pauli Hadamard distribution is the same
    physical measurement model as experiment 4. A vectorized binomial draw
    samples independent settings; S-lag reuse is applied only when assembling
    matrices. Distinct stages use independent random streams.
    """
    def __init__(self, data: dict, branch: dict, problem: dict,
                 layout: SettingLayout, branch_id: int, grid_name: str):
        self.layout = layout
        L, U = problem['L'], problem['U']
        self.info = {'scale': 2*(L-1)+U*L/4,
                     'shift': problem['E0']+U*L/4,
                     'sign': branch['energy_sign'],
                     'beta': float(torch.linalg.vector_norm(branch['b']))}
        S = data['S'].detach().cpu()
        Hbar = self.info['sign']*data['T'].detach().cpu() + self.info['shift']*S
        means = []
        for key in layout.keys:
            if key[0] == 'S':
                i,j = next((i,j) for i in range(layout.m) for j in range(layout.m)
                           if layout.q[j]-layout.q[i] == key[1])
                val = complex(S[i,j])
            else:
                val = complex(Hbar[key[1],key[2]]) / self.info['scale']
            means.append(val.real if key[-1] == 'R' else val.imag)
        self._means = torch.tensor(means, dtype=RDTYPE)
        check(float(self._means.abs().max()) <= 1+1e-8, 'Outcome mean outside [-1,1].')
        self._means.clamp_(-1,1)
        self._label = f'{L}|{U:.12g}|{branch_id}|{grid_name}'

    def sample(self, counts: torch.Tensor, seed: int, stage: str) -> torch.Tensor:
        counts = counts.detach().cpu().to(torch.int64)
        check(counts.shape == self._means.shape and int(counts.min()) > 0,
              'Invalid per-setting allocation.')
        token = f'{self._label}|seed={seed}|stage={stage}'
        digest = hashlib.sha256(token.encode()).digest()
        generator = torch.Generator(device='cpu').manual_seed(
            int.from_bytes(digest[:8], 'little') % (2**63-1))
        hits = torch.binomial(counts.to(RDTYPE), (1+self._means)/2,
                              generator=generator)
        return 2*hits/counts-1


def spectral_sensitivities(observations: torch.Tensor, counts: torch.Tensor,
                           layout: SettingLayout, info: dict,
                           omega: torch.Tensor) -> tuple[torch.Tensor,dict]:
    """First-order integrated spectral variance in a FROZEN pilot subspace.

    Includes shared S-lag covariance and f=beta*S[:,0]. Does not differentiate
    hard rank changes. Neither a rigorous error bar nor an optimality theorem.
    """
    check(bool((counts[:layout.ns] == counts[0]).all()), 'S shots must be uniform within a branch.')
    S,T = layout.matrices(observations, info)
    C, audit = whiten_source(S, int(counts[0]))
    f = info['beta']*S[:,0]
    Tp, fp = C.mH@T@C, C.mH@f
    ev,V = torch.linalg.eigh((Tp+Tp.mH)/2)
    alpha, CV = V.mH@fp, C@V
    z = omega+1j*ETA
    den = z[None,:]-ev[:,None]
    x = CV@(alpha[:,None]/den)
    # y is the transpose of f^dagger (zS-T)^-1, NOT x.conjugate().
    y = CV.conj()@(alpha.conj()[:,None]/den)
    ES, EH = layout.ES, layout.EH
    dS = info['beta']*(ES[:,0,:]@x+ES[:,:,0]@y)
    dS = dS-(z+info['sign']*info['shift'])[None,:]*torch.einsum('iw,kij,jw->kw',y,ES,x)
    dH = info['sign']*info['scale']*torch.einsum('iw,kij,jw->kw',y,EH,x)
    spectral_gradient = -torch.cat((dS,dH),dim=0).imag/math.pi
    observed_variance = (1-observations.to(layout.device).square()).clamp_min(VARIANCE_FLOOR)
    risk = integral(spectral_gradient.square(),omega)*observed_variance
    check(bool(torch.isfinite(risk).all()) and float(risk.min()) >= 0,
          'Nonfinite sensitivity score.')
    return risk.detach().cpu(), audit


def allocate_counts(total: int, risks: list[torch.Tensor], layout: SettingLayout,
                    policy: str) -> torch.Tensor:
    """Allocate one combined budget to two branches; round DOWN and report unused shots.

    All S settings within each branch receive equal counts so the original
    scalar S-noise cutoff retains an unambiguous interpretation.
    """
    scores = torch.stack(risks).to(device='cpu',dtype=RDTYPE)
    check(scores.shape == (2,layout.nsettings), 'Allocation shape mismatch.')
    if policy in ('uniform','pilot_control'):
        weights = torch.ones_like(scores)
    elif policy.startswith('fixed'):
        fraction = int(policy[5:])/100
        check(0 < fraction < 1, 'Invalid fixed split.')
        weights = torch.empty_like(scores)
        weights[:,:layout.ns] = fraction/(2*layout.ns)
        weights[:,layout.ns:] = (1-fraction)/(2*(layout.nsettings-layout.ns))
    elif policy == 'adaptive':
        weights = scores.sqrt()
        weights[:,:layout.ns] = scores[:,:layout.ns].mean(dim=1).sqrt()[:,None]
        if float(weights.sum()) == 0:
            weights = torch.ones_like(weights)
        weights = ALLOCATION_UNIFORM_FLOOR/weights.numel() + (
            1-ALLOCATION_UNIFORM_FLOOR)*weights/weights.sum()
    else:
        raise ValueError(f'Unknown allocation policy: {policy}')
    result = torch.floor(total*weights/weights.sum()).to(torch.int64)
    check(int(result.min()) > 0 and int(result.sum()) <= total, 'Allocation exceeds budget or has empty settings.')
    check(bool((result[:,:layout.ns] == result[:,0:1]).all()), 'Unequal S-lag counts.')
    return result


def new_measurement_tests(device: torch.device) -> dict:
    problem = build_problem(4,4.,device)
    branch = problem['branches'][0]
    data,_,_ = fixed_time_pool(4,4.,branch,12,.5,.125)
    layout = SettingLayout(time_indices(12),device)
    backend = SamplingBackend(data,branch,problem,layout,0,'test12')
    # Evaluator-only access: test probability/matrix reconstruction.
    mu = backend._means
    S,T = layout.matrices(mu,backend.info)
    matrix_error = max(float((S-data['S']).abs().max()),float((T-data['T']).abs().max()))
    check(matrix_error < 1e-8,'Vectorized measurement geometry is incorrect.')
    counts = torch.full((layout.nsettings,),10**9,dtype=torch.int64)
    omega = torch.linspace(-8,8,61,dtype=RDTYPE,device=device)
    risk, _ = spectral_sensitivities(mu,counts,layout,backend.info,omega)
    # Independent finite differences of the FULL generalized projected solve
    # with C fixed, including S dependence of f and the exact energy shift.
    C,_ = whiten_source(S,10**9)
    z = omega+1j*ETA
    def frozen_green(value: torch.Tensor) -> torch.Tensor:
        ss,tt = layout.matrices(value,backend.info)
        ff = C.mH@(backend.info['beta']*ss[:,0])
        sm,tm = C.mH@ss@C,C.mH@tt@C
        xx = torch.linalg.solve(z[:,None,None]*sm[None,:,:]-tm[None,:,:],
                                ff.expand(len(z),-1))
        return (ff.conj()[None,:]*xx).sum(dim=1)
    relative_errors = []
    for index in (0,1,layout.ns-2,layout.ns,layout.ns+1,layout.ns+2,layout.nsettings-1):
        plus,minus = mu.clone(),mu.clone()
        eps = 1e-7
        plus[index] += eps; minus[index] -= eps
        derivative = -(frozen_green(plus)-frozen_green(minus)).imag/(2*eps*math.pi)
        expected = float(integral(derivative.square(),omega))*max(VARIANCE_FLOOR,1-float(mu[index])**2)
        actual = float(risk[index])
        rel = abs(actual-expected)/max(1e-12,abs(expected))
        check(rel < 2e-4,f'Spectral sensitivity finite-difference mismatch: {rel:g}')
        relative_errors.append(rel)
    for policy in ('uniform','fixed10','fixed50','pilot_control','adaptive'):
        nn = allocate_counts(10**6,[risk,risk],layout,policy)
        check(int(nn.sum()) <= 10**6,'Allocation test exceeded global budget.')
    nn = torch.full((layout.nsettings,),10000,dtype=torch.int64)
    v1 = backend.sample(nn,7,'pilot')
    v2 = backend.sample(nn,7,'production')
    check(not bool(torch.equal(v1,v2)), 'Pilot and production streams were reused.')
    return {'vectorized_matrix_reconstruction_max_error':matrix_error,
            'sensitivity_finite_difference_max_relative_error':max(relative_errors),
            'source_dependence_and_shared_lags_in_derivative':True,
            'independent_pilot_and_production_streams':True,
            'allocation_count_tests':True}


def audit_experiment4_noise(directory:Path, log:Any, device:torch.device) -> list[dict]:
    """Controlled component replacement, NOT a physically free measurement protocol.

    Reuses the experiment-4 RNG exactly. Components made exact here are
    deliberately uncharged diagnostics, never counted as competing methods.
    """
    rows=[]
    omega=torch.linspace(-12,12,2401,dtype=RDTYPE,device=device); z=omega+1j*ETA
    for U in (2.,4.,8.):
        problem=build_problem(6,U,device); branches=problem['branches']
        data=[fixed_time_pool(6,U,br,24,.5,.125)[0] for br in branches]
        truth=-sum(green(br['K'],br['b'],z) for br in branches).imag/math.pi
        mass=float(integral(truth,omega))
        q=time_indices(24); quota=setting_quota('prefix24',24,q); shots=10**8//(2*quota)
        for seed in range(5):
            values={name:[] for name in ('ideal','cutoff_only','S_noise_only','H_noise_only','both')}
            ranks={name:[] for name in values}
            for bid,(d,br) in enumerate(zip(data,branches)):
                svc=MeasurementService(d,br,U,6,problem['E0'],shots,seed,bid,q,quota)
                Sn,Tn=svc.matrices(list(range(24)))
                S,T=d['S'],d['T']
                H=br['energy_sign']*T+svc.shift*S
                Hn=br['energy_sign']*Tn+svc.shift*Sn
                variants=[('ideal',S,H,None),('cutoff_only',S,H,shots),
                          ('S_noise_only',Sn,H,shots),('H_noise_only',S,Hn,shots),('both',Sn,Hn,shots)]
                for name,s,h,n in variants:
                    G,info=project_measured(s,br['energy_sign']*(h-svc.shift*s),svc.beta,z,n)
                    values[name].append(G);ranks[name].append(info['rank'])
            for name,v in values.items():
                error=float(integral((-sum(v).imag/math.pi-truth).abs(),omega))/mass
                rows.append({'U':U,'seed':seed,'component_test':name,'relative_L1_window':error,
                             'rank_add':ranks[name][0],'rank_remove':ranks[name][1]})
        log('  AUDIT U='+str(U)+': '+'; '.join(
            name+'=%'+f'{100*statistics.median(r["relative_L1_window"] for r in rows if r["U"]==U and r["component_test"]==name):.3f}'
            for name in values))
    csv_write(directory/'experiment4_component_audit.csv',rows)
    return rows


def run_allocation(args:argparse.Namespace,directory:Path,log:Any) -> dict:
    torch.set_num_threads(args.threads)
    device=get_device(args.device)
    dump_json(directory/'environment.json',environment(device))
    log(f'Cihaz: {device}; PyTorch: {torch.__version__}; complex128')
    log('[1] Fizik, olcum modeli, butce ve turev dogrulamalari...')
    tests=self_tests(device)
    tests.update(extra_tests(device)); tests.update(measurement_tests(device))
    tests.update(new_measurement_tests(device))
    dump_json(directory/'self_tests.json',tests)
    log('Dogrulama: PASS')
    if args.suite == 'development':
        cases=[(6,2.),(6,4.),(6,8.)]; budgets=[10**7,10**8,10**9]
        start_seed=0; repeats=args.seeds if args.seeds is not None else 20
    elif args.suite == 'validation':
        cases=[(6,3.),(6,6.)]; budgets=[10**7,10**8,10**9]
        start_seed=1000; repeats=args.seeds if args.seeds is not None else 30
    else:
        cases=[(6,4.)]; budgets=[10**8]; start_seed=0
        repeats=args.seeds if args.seeds is not None else 2
    seed_ids=list(range(start_seed,start_seed+repeats))
    limitations=[
        'No circuit search; fixed layouts. Adaptive shot allocation is an existing research direction.',
        'Exact source states, source norms and E0 are free for all methods; no preparation costs.',
        'Ideal gates; only exact binomial shot noise is simulated. No quantum hardware execution.',
        'Coefficient-weighted random-Pauli Hadamard measurements are not an optimal grouping baseline.',
        'No additional particle-hole or time-reversal symmetry sharing is used.',
        'All comparisons use total shot count, NOT equal native gates or total physical runtime.',
        'Pilot is charged and discarded for final estimation; production data are independent of pilot data.',
        'Pilot risks use a frozen truncated subspace; no derivative through changing rank.',
        'Same heuristic Gram cutoff factor 2; this is not a confidence certificate.',
        'Risk targets integrated squared local spectral variation; evaluation uses relative L1.',
        'Methods share seed labels; policy outcomes are not independent samples.',
        'The post-hoc best fixed median is an evaluator-only envelope, not an executable policy.',
        'Development U=2/4/8 was inspected before; validation U=3/6 must not be recycled as held-out after tuning.',
        'No novelty, speedup, statistical-significance or publication-readiness claim.'
    ]
    cfg={'version':VERSION,'suite':args.suite,'cases':cases,'budgets':budgets,'seed_ids':seed_ids,
         'variants':EXPERIMENT5_VARIANTS,'eta':ETA,'time_spacing':SPACING,'product_step':PRODUCT_STEP,
         'evaluation_grid':[-12,12,2401],'pilot_gradient_grid':[-12,12,241],
         'pilot_fraction':PILOT_FRACTION,'allocation_uniform_floor':ALLOCATION_UNIFORM_FLOOR,
         'variance_floor':VARIANCE_FLOOR,'cutoff_factor':NOISE_CUTOFF_FACTOR,'limits':limitations}
    cfg_blob=json.dumps(cfg,sort_keys=True,ensure_ascii=False).encode()
    cfg['settings_sha256']=hashlib.sha256(cfg_blob).hexdigest()
    dump_json(directory/'config.json',cfg)
    # This file is written BEFORE any new benchmark result is evaluated.
    log('Ayar ozeti SHA256: '+cfg['settings_sha256'])
    if args.audit4:
        log('[2] Deney 4 bilesen denetimi (ucretsiz kesin bilgi yalniz teshis icin)...')
        audit_experiment4_noise(directory,log,device)
    omega=torch.linspace(-12,12,2401,dtype=RDTYPE,device=device);z=omega+1j*ETA
    wpilot=torch.linspace(-12,12,241,dtype=RDTYPE,device=device)
    q=time_indices(24)
    grid_indices={
        'prefix24':list(range(24)),
        'prefix16':list(range(16)),
        'spread16':predetermined('spread16',16,q),
    }
    layouts={name:SettingLayout([q[i] for i in ids],device) for name,ids in grid_indices.items()}
    rows=[]; ideal_rows=[]; summaries=[]; allocation_samples={}; start=time.perf_counter()
    for L,U in cases:
        log(f'[3] L={L}, U/t={U:g}, suite={args.suite}: sabit devreler, olcum dagilimi')
        problem=build_problem(L,U,device);branches=problem['branches']
        # Simulator preparation and independent exact evaluator, never given to allocator.
        full_data=[fixed_time_pool(L,U,br,24,SPACING,PRODUCT_STEP)[0] for br in branches]
        truth=-sum(green(br['K'],br['b'],z) for br in branches).imag/math.pi
        mass=float(integral(truth,omega))
        backend_by_grid={}
        for grid,indices in grid_indices.items():
            layout=layouts[grid];backends=[];ideals=[]
            ix=torch.tensor(indices,dtype=torch.long,device=device)
            for bid,(d,br) in enumerate(zip(full_data,branches)):
                ds={name:d[name][ix[:,None],ix[None,:]] for name in ('S','T')}
                back=SamplingBackend(ds,br,problem,layout,bid,grid)
                backends.append(back)
                # Evaluator-only ideal result, not available to gradient/allocator.
                G,_=project_measured(ds['S'],ds['T'],back.info['beta'],z,None)
                ideals.append(G)
            ideal_error=float(integral((-sum(ideals).imag/math.pi-truth).abs(),omega))/mass
            ideal_rows.append({'L':L,'U':U,'grid':grid,'relative_L1_window':ideal_error})
            backend_by_grid[grid]=backends
        for B in budgets:
            for seed in seed_ids:
                for grid,indices in grid_indices.items():
                    layout=layouts[grid];backends=backend_by_grid[grid]
                    policies=[policy for g,policy in EXPERIMENT5_VARIANTS if g==grid]
                    # Shared simulator cache; charged once within EACH workflow that uses it.
                    pilot_counts=torch.full((2,layout.nsettings),
                        int(PILOT_FRACTION*B)//(2*layout.nsettings),dtype=torch.int64)
                    risks=[torch.ones(layout.nsettings,dtype=RDTYPE) for _ in range(2)]
                    pilot_info=[]
                    if any(p in ('adaptive','pilot_control') for p in policies):
                        for bid,backend in enumerate(backends):
                            measurements=backend.sample(pilot_counts[bid],seed,'pilot')
                            risk,info=spectral_sensitivities(measurements,pilot_counts[bid],layout,backend.info,wpilot)
                            risks[bid]=risk;pilot_info.append(info)
                    for policy in policies:
                        uses_pilot=policy in ('adaptive','pilot_control')
                        pilot_used=int(pilot_counts.sum()) if uses_pilot else 0
                        production_counts=allocate_counts(B-pilot_used,risks,layout,policy)
                        total_counts=production_counts+(pilot_counts if uses_pilot else 0)
                        actual=int(total_counts.sum())
                        check(actual<=B,'Total acquisition exceeded budget.')
                        greens=[];infos=[]
                        for bid,backend in enumerate(backends):
                            measured=backend.sample(production_counts[bid],seed,'production')
                            S,T=layout.matrices(measured,backend.info)
                            G,info=project_measured(S,T,backend.info['beta'],z,int(production_counts[bid,0]))
                            greens.append(G);infos.append(info)
                        spectrum=-sum(greens).imag/math.pi
                        check(bool(torch.isfinite(spectrum).all()) and float(spectrum.min())>-1e-6,
                              'Invalid finite-shot spectrum.')
                        error=float(integral((spectrum-truth).abs(),omega))/mass
                        rotations_per_tick=round(SPACING/PRODUCT_STEP)*(4*(L-1)+L)
                        proxy=int((total_counts*layout.time_tick_cost[None,:]).sum())*rotations_per_tick
                        row={'L':L,'U':U,'budget':B,'seed':seed,'grid':grid,'policy':policy,
                             'input_states_per_branch':layout.m,'relative_L1_window':error,
                             'actual_shots':actual,'unused_shots':B-actual,'pilot_shots':pilot_used,
                             'S_shots_total':int(total_counts[:,:layout.ns].sum()),
                             'H_shots_total':int(total_counts[:,layout.ns:].sum()),
                             'production_S_shots_per_setting_add':int(production_counts[0,0]),
                             'production_S_shots_per_setting_remove':int(production_counts[1,0]),
                             'rank_add':infos[0]['rank'],'rank_remove':infos[1]['rank'],
                             'cutoff_add':infos[0]['cutoff'],'cutoff_remove':infos[1]['cutoff'],
                             'shot_weighted_rotation_proxy':proxy,
                             'source_mass_total':sum(i['source_mass'] for i in infos)}
                        check(abs(row['source_mass_total']-1)<5e-5,'Global source mass changed.')
                        rows.append(row)
                        if seed==seed_ids[0]:
                            key=f'L{L}_U{U:g}_B{B}_{grid}_{policy}'
                            allocation_samples[key]={
                                'keys':layout.keys,'q':layout.q,'pilot_counts':pilot_counts.tolist() if uses_pilot else None,
                                'production_counts':production_counts.tolist(),'pilot_ranks':pilot_info if uses_pilot else [],
                                'final_rank_info':infos}
            ss={}
            for grid,policy in EXPERIMENT5_VARIANTS:
                group=[r for r in rows if r['L']==L and r['U']==U and r['budget']==B
                       and r['grid']==grid and r['policy']==policy]
                val={'L':L,'U':U,'budget':B,'grid':grid,'policy':policy,'n':len(group),
                     'median_error':statistics.median(r['relative_L1_window'] for r in group),
                     'min_error':min(r['relative_L1_window'] for r in group),
                     'max_error':max(r['relative_L1_window'] for r in group),
                     'median_rotation_proxy':statistics.median(r['shot_weighted_rotation_proxy'] for r in group),
                     'median_S_fraction':statistics.median(r['S_shots_total']/B for r in group)}
                summaries.append(val);ss[(grid,policy)]=val
            fixed=[v for k,v in ss.items() if k[1] not in ('adaptive','pilot_control')]
            best=min(fixed,key=lambda r:r['median_error'])
            log(f'  B={B:.0e}, n={repeats}: uniform24=%{100*ss[("prefix24","uniform")]["median_error"]:.3f}; '
                f'adaptive24=%{100*ss[("prefix24","adaptive")]["median_error"]:.3f}; '
                f'spread16=%{100*ss[("spread16","uniform")]["median_error"]:.3f}; '
                f'adaptive_spread16=%{100*ss[("spread16","adaptive")]["median_error"]:.3f}; '
                f'en-iyi-sabit-sonradan=%{100*best["median_error"]:.3f}({best["grid"]}/{best["policy"]})')
            csv_write(directory/'metrics.csv',rows)
            csv_write(directory/'ideal_metrics.csv',ideal_rows)
            dump_json(directory/'allocation_examples.json',allocation_samples)
    if device.type=='cuda':torch.cuda.synchronize(device.index)
    result={'status':'PASS','stage':'fixed-circuit pilot-guided allocation diagnostic',
            'config':cfg,'self_tests':tests,'summary':summaries,'rows':len(rows),
            'wall_seconds':time.perf_counter()-start,'limits':limitations}
    dump_json(directory/'summary.json',result)
    log('\nSONUC: PASS (hesap/olcum dogrulamasi; makale veya ustunluk sonucu DEGIL)')
    log(f'Suite={args.suite}; her butce/durum icin n={repeats}. Pilot maliyeti dahil, final veriden ayri.')
    for L,U in cases:
        for B in budgets:
            ss={(r['grid'],r['policy']):r for r in summaries if r['L']==L and r['U']==U and r['budget']==B}
            fixed=[v for k,v in ss.items() if k[1] not in ('adaptive','pilot_control')]
            best=min(fixed,key=lambda r:r['median_error'])
            log(f'U/t={U:g}, B={B:.0e}: uniform24=%{100*ss[("prefix24","uniform")]["median_error"]:.3f}; '
                f'adaptive24=%{100*ss[("prefix24","adaptive")]["median_error"]:.3f}; '
                f'spread16=%{100*ss[("spread16","uniform")]["median_error"]:.3f}; '
                f'adaptive_spread16=%{100*ss[("spread16","adaptive")]["median_error"]:.3f}; '
                f'en-iyi-sabit-sonradan=%{100*best["median_error"]:.3f}')
    log('En-iyi-sabit: gercek hataya bakarak SONRADAN kurulan karsilastirma zarfi; bir secim algoritmasi degil.')
    log('Ayni shots sayisi, ayni kapi maliyeti demek degil. Tam kaynak/E0; kapi gurultusu yok.')
    log('Uyarlamali olcum dagilimi zaten bilinen bir alandir. Kesim sezgisel, kesin hata siniri yok.')
    return result


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--device',default='cuda')
    parser.add_argument('--out',type=Path,default=Path.home()/'spektrum_deney5')
    parser.add_argument('--suite',choices=('development','validation','smoke'),default='validation')
    parser.add_argument('--seeds',type=int,default=None,help='Default: development 20, validation 30, smoke 2.')
    parser.add_argument('--threads',type=int,default=2)
    parser.add_argument('--audit4',action='store_true',help='Also reproduce experiment-4 noise component audit.')
    args=parser.parse_args()
    if not 1<=args.threads<=64:parser.error('--threads 1..64 olmali')
    if args.seeds is not None and not 1<=args.seeds<=200:parser.error('--seeds 1..200 olmali')
    root=args.out.expanduser().resolve()
    tag=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:6]
    directory=root/f'run5_{tag}';directory.mkdir(parents=True,exist_ok=False)
    def log(message:str) -> None:
        print(message,flush=True)
        with (directory/'run.log').open('a',encoding='utf-8') as f:f.write(message+'\n')
    status=0
    try:
        source=Path(__file__).read_bytes();(directory/'script_snapshot.py').write_bytes(source)
        dump_json(directory/'provenance.json',{'script_sha256':hashlib.sha256(source).hexdigest(),
                  'utc':tag,'argv':sys.argv,'version':VERSION})
        with torch.inference_mode():run_allocation(args,directory,log)
    except (Exception,KeyboardInterrupt) as exc:
        status=1;text=traceback.format_exc()
        (directory/'error.txt').write_text(text,encoding='utf-8')
        dump_json(directory/'failure.json',{'status':'FAILED','type':type(exc).__name__,'error':str(exc)})
        log('\nHATA: '+str(exc));log(text)
    finally:
        archive=root/f'rapor5_{tag}.zip'
        with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as zf:
            for p in sorted(directory.rglob('*')):
                if p.is_file():zf.write(p,arcname=p.relative_to(directory))
        print(f'\nRAPOR_ZIP: {archive}',flush=True)
        print('SONUC bolumunu veya hata ciktisini paylas.',flush=True)
    return status


if __name__=='__main__':raise SystemExit(main())
