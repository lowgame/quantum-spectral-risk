#!/usr/bin/env python3
"""Resume an interrupted, unmodified experiment-6 run.

Python >=3.10; the same PyTorch environment as the original run is required.
The original script_snapshot.py is hash-checked and imported as the scientific
kernel. No fitting settings, measurement policies, seeds or comparisons change.
Completed cases are validated and skipped. Raw saved observations are reused.
A backup ZIP is made before changing result files. Each new completed case gets
an fsync'd atomic checkpoint before aggregate CSV/JSON files are rewritten.

A machine shutdown still stops computation: run this command again after boot.
No system services, package installation or automatic reboot jobs are created.
"""
from __future__ import annotations

import argparse
import csv
import fcntl
import hashlib
import importlib.util
import io
import json
import math
import os
import shutil
import statistics
import sys
import time
import traceback
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

KERNEL_SHA256 = '519d65fd8774f49dc562e6fb733302ab96a8082fe52071edfc07ff125d483306'
METHODS = ('raw_cutoff', 'gram_psd_cutoff', 'joint_psd_cutoff',
           'latent_diagonal_cv', 'latent_joint_cv')
FIELDS = ('U', 'budget', 'seed', 'method', 'relative_L1_window',
          'actual_shots', 'unused_shots', 'shot_weighted_rotation_proxy')


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


def fsync_dir(path: Path) -> None:
    fd = os.open(str(path), os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_bytes(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.pending-' + uuid.uuid4().hex[:8])
    try:
        with tmp.open('xb') as out:
            out.write(content)
            out.flush()
            os.fsync(out.fileno())
        os.replace(tmp, path)
        fsync_dir(path.parent)
    finally:
        if tmp.exists():
            tmp.unlink()


def atomic_json(path: Path, value: Any) -> None:
    atomic_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2,
                                   allow_nan=False) + '\n').encode('utf-8'))


def atomic_csv(path: Path, rows: list[dict]) -> None:
    require(bool(rows), 'Bos CSV yazilmadi: ' + str(path))
    buf = io.StringIO(newline='')
    writer = csv.DictWriter(buf, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
    atomic_bytes(path, buf.getvalue().encode('utf-8'))


def key_for(U: float, B: int, seed: int) -> str:
    return f'U{U:g}_B{B}_seed{seed}'


def config_and_kernel(directory: Path):
    snapshot = directory / 'script_snapshot.py'
    require(snapshot.is_file(), 'script_snapshot.py bulunamadi; farkli bir klasor secilmis olabilir.')
    source = snapshot.read_bytes()
    require(hashlib.sha256(source).hexdigest() == KERNEL_SHA256,
            'Kayitli bilimsel kod beklenen surumle eslesmiyor. Dosyalar degistirilmedi.')
    cfg = read_json(directory / 'config.json')
    test = {k: v for k, v in cfg.items() if k != 'settings_sha256'}
    require(hashlib.sha256(json.dumps(test, sort_keys=True).encode()).hexdigest()
            == cfg['settings_sha256'], 'Ayar SHA256 dogrulamasi basarisiz.')
    expected = {'version': '0.6.1-joint-latent-pilot', 'L': 6,
                'ranks': [6, 10, 14], 'fit_steps': 350,
                'training_fraction': .8, 'input_circuits_per_branch': 24,
                'eta': .2, 'spacing': .5, 'layout': 'prefix24', 'allocation': 'uniform'}
    for k, v in expected.items():
        require(cfg.get(k) == v, f'Beklenmeyen deney ayari: {k}')
    require(cfg.get('product_step') in (.125, .25), 'Beklenmeyen product_step.')
    spec = importlib.util.spec_from_file_location('_experiment6_verified_kernel', snapshot)
    require(spec is not None and spec.loader is not None, 'Bilimsel kod yuklenemedi.')
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    mod.PRODUCT_STEP = cfg['product_step']
    # Persistence only: no numerical kernels are replaced.
    mod.dump_json, mod.csv_write = atomic_json, atomic_csv
    expected_cases = [(float(U), int(B), int(s)) for U in cfg['U']
                      for B in cfg['budgets'] for s in cfg['seeds']]
    require(len(set(expected_cases)) == len(expected_cases), 'Yinelenen deney ayari.')
    return cfg, mod, expected_cases


def typed_row(row: dict) -> dict:
    require(set(row) == set(FIELDS), 'Eksik/fazla CSV alani.')
    converted = {'U': float(row['U']), 'budget': int(row['budget']),
                 'seed': int(row['seed']), 'method': row['method'],
                 'relative_L1_window': float(row['relative_L1_window']),
                 'actual_shots': int(row['actual_shots']), 'unused_shots': int(row['unused_shots']),
                 'shot_weighted_rotation_proxy': int(row['shot_weighted_rotation_proxy'])}
    require(converted['method'] in METHODS, 'Taninmayan yontem.')
    require(math.isfinite(converted['relative_L1_window']) and converted['relative_L1_window'] >= 0,
            'Gecersiz hata degeri.')
    require(converted['actual_shots'] > 0 and converted['unused_shots'] >= 0 and
            converted['actual_shots'] + converted['unused_shots'] == converted['budget'],
            'Tutarsiz olcum butcesi.')
    require(converted['shot_weighted_rotation_proxy'] >= 0, 'Gecersiz maliyet.')
    return converted


def inspect_saved(directory: Path, expected_cases: list[tuple], log):
    """Do not trust a terminal PASS or a CSV row alone as a complete case."""
    allowed = {key_for(*case) for case in expected_cases}
    grouped: dict[str, list[dict]] = {}
    bad = set()
    path = directory / 'metrics.csv'
    if path.exists():
        try:
            with path.open(encoding='utf-8', newline='') as inp:
                for raw in csv.DictReader(inp):
                    try:
                        row = typed_row(raw)
                        key = key_for(row['U'], row['budget'], row['seed'])
                        require(key in allowed, 'Ayarlar disinda kayit: ' + key)
                        grouped.setdefault(key, []).append(row)
                    except (ValueError, TypeError, RuntimeError) as exc:
                        log('UYARI: Tam olmayan CSV satiri korunacak, eksik kosul yeniden hesaplanacak: ' + str(exc))
                        try:
                            bad.add(key_for(float(raw['U']), int(raw['budget']), int(raw['seed'])))
                        except (ValueError, TypeError, KeyError):
                            pass
        except (csv.Error, UnicodeError) as exc:
            raise RuntimeError('CSV okunamadi; yeniden hesaplamadan once dosya incelemesi gerekli.') from exc
    details_path = directory / 'details.json'
    details = read_json(details_path) if details_path.exists() else {}
    require(isinstance(details, dict), 'details.json beklenen bicimde degil.')
    # New checkpoints take precedence if shutdown interrupted an aggregate write.
    for path in sorted((directory / 'resume_checkpoints').glob('U*.json')):
        checkpoint = read_json(path)
        key = checkpoint['key']
        require(key in allowed, 'Beklenmeyen checkpoint: ' + key)
        require(checkpoint['settings_sha256'] == read_json(directory/'config.json')['settings_sha256'],
                'Checkpoint ayarlari farkli.')
        grouped[key] = [typed_row(r) for r in checkpoint['rows']]
        details[key] = checkpoint['details']
        bad.discard(key)
    complete = set()
    rows = []
    for case in expected_cases:
        key = key_for(*case)
        group = grouped.get(key, [])
        methods = [r['method'] for r in group]
        audits = details.get(key, {})
        curve = directory / f'curves_{key}.csv'
        valid = (key not in bad and len(group) == len(METHODS)
                 and set(methods) == set(METHODS)
                 and isinstance(audits, dict) and set(audits) == set(METHODS)
                 and all(isinstance(audits[x], list) and len(audits[x]) == 2 for x in METHODS)
                 and curve.is_file())
        if valid:
            # Validate all curve numbers and their agreement with recorded errors.
            try:
                with curve.open(encoding='utf-8', newline='') as inp:
                    cr = list(csv.DictReader(inp))
                valid = (len(cr) == 2401 and set(cr[0]) == {'omega', 'exact', *METHODS})
                if valid:
                    vals = {k: [float(r[k]) for r in cr] for k in cr[0]}
                    valid = all(math.isfinite(x) for col in vals.values() for x in col)
                    w = vals['omega']
                    valid = valid and all(w[j+1] > w[j] for j in range(len(w)-1))
                    def trap(y):
                        return sum((w[j+1]-w[j])*(y[j+1]+y[j])*.5 for j in range(len(w)-1))
                    mass = trap(vals['exact'])
                    valid = valid and mass > 0
                    for row in group:
                        err = trap([abs(x-y) for x,y in zip(vals[row['method']], vals['exact'])]) / mass
                        valid = valid and math.isclose(err, row['relative_L1_window'], rel_tol=1e-8, abs_tol=1e-10)
            except (ValueError, KeyError, IndexError, ZeroDivisionError, csv.Error):
                valid = False
        if valid:
            complete.add(key)
            rows.extend(sorted(group, key=lambda r: METHODS.index(r['method'])))
        elif group:
            log('UYARI: Eksik/tutarsiz kosul atlanmayacak: ' + key)
    cleaned_details = {k: details[k] for k in complete}
    return rows, cleaned_details, complete


def archive_directory(directory: Path, target: Path) -> None:
    tmp = target.with_name(target.name + '.pending')
    try:
        with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(directory.rglob('*')):
                if path.is_file() and not path.is_symlink() and path.name != 'resume.lock':
                    archive.write(path, path.relative_to(directory))
        with tmp.open('rb') as stream:
            os.fsync(stream.fileno())
        os.replace(tmp, target)
        fsync_dir(target.parent)
    finally:
        if tmp.exists():
            tmp.unlink()


def observations(mod, directory, U, B, seed, bid, backend, layout, ct, cv):
    torch = mod.torch
    path = directory / f'raw_U{U:g}_B{B}_seed{seed}_branch{bid}.json'
    if path.exists():
        raw = read_json(path)
        require(raw['q'] == layout.q and raw['keys'] == [list(k) for k in layout.keys],
                'Kayitli ham olcum geometrisi farkli: ' + path.name)
        require(raw['counts_train'] == ct.tolist() and raw['counts_validation'] == cv.tolist(),
                'Kayitli ham olcum butcesi farkli: ' + path.name)
        for key, val in backend.info.items():
            require(math.isclose(float(raw['info'][key]), float(val), rel_tol=1e-10, abs_tol=1e-10),
                    'Ham olcum model bilgisi uyusmuyor: ' + key)
        yt = torch.tensor(raw['observed_train'], dtype=mod.RDTYPE)
        yv = torch.tensor(raw['observed_validation'], dtype=mod.RDTYPE)
        require(yt.shape == ct.shape and yv.shape == cv.shape and
                bool(torch.isfinite(yt).all()) and bool(torch.isfinite(yv).all()) and
                float(yt.abs().max()) <= 1 + 1e-12 and float(yv.abs().max()) <= 1 + 1e-12,
                'Kayitli ham olcumler gecersiz: ' + path.name)
        return yt, yv, raw['info']
    yt = backend.sample(ct, seed, 'mavi_train')
    yv = backend.sample(cv, seed, 'mavi_validation')
    atomic_json(path, {'keys': layout.keys, 'q': layout.q, 'info': backend.info,
                      'counts_train': ct.tolist(), 'counts_validation': cv.tolist(),
                      'observed_train': yt.tolist(), 'observed_validation': yv.tolist()})
    return yt, yv, backend.info


def resume_run(mod, cfg, directory, device_name, rows, details, complete, log, session):
    torch = mod.torch
    env = read_json(directory/'environment.json') if (directory/'environment.json').exists() else {}
    threads = int(env.get('cpu_threads', 2))
    require(1 <= threads <= 32, 'Kayitli CPU thread ayari gecersiz.')
    torch.set_num_threads(threads)
    device = mod.get_device(device_name)
    atomic_json(directory/f'environment_resume_{session}.json', mod.environment(device))
    log(f'Cihaz: {device}; PyTorch: {torch.__version__}; onceki thread sayisi: {threads}')
    log('[1] Onceki fizik/model dogrulamalari yeniden kontrol ediliyor...')
    with torch.no_grad():
        tests = mod.self_tests(device)
        tests.update(mod.extra_tests(device))
    tests.update(mod.new_tests())
    atomic_json(directory/f'self_tests_resume_{session}.json', tests)
    log('Dogrulama: PASS')
    layout = mod.SettingLayout(mod.time_indices6(24), torch.device('cpu'))
    omega = torch.linspace(-12, 12, 2401, dtype=mod.RDTYPE)
    z = omega + 1j*mod.ETA
    total = len(cfg['U'])*len(cfg['budgets'])*len(cfg['seeds'])
    clock = time.perf_counter()
    for U0 in cfg['U']:
        U = float(U0)
        pending = [(int(B), int(s)) for B in cfg['budgets'] for s in cfg['seeds']
                   if key_for(U, int(B), int(s)) not in complete]
        if not pending:
            continue
        log(f'[2] L=6 U/t={U:g}; eksik kosul sayisi: {len(pending)}')
        with torch.no_grad():
            prob = mod.build_problem(6, U, device)
            truth = -sum(mod.green(br['K'], br['b'], z.to(device))
                         for br in prob['branches']).imag.cpu()/math.pi
            mass = float(mod.integral(truth, omega))
            backends = []
            for bid, br in enumerate(prob['branches']):
                data, _, _ = mod.fixed_time_pool(6, U, br, 24, mod.SPACING, mod.PRODUCT_STEP)
                backends.append(mod.SamplingBackend(data, br, prob, layout, bid, 'prefix24'))
        for B, seed in pending:
            key = key_for(U, B, seed)
            log(f'BASLIYOR: {key} | tamamlanan={len(complete)}/{total}')
            cn = torch.full((layout.nsettings,), B//(2*layout.nsettings), dtype=torch.int64)
            ct = torch.floor(cn.to(mod.RDTYPE)*mod.FIT_FRACTION).to(torch.int64)
            cv = cn-ct
            used = 2*int(cn.sum())
            greens = {v: [] for v in METHODS}
            audits = {v: [] for v in METHODS}
            for bid, backend in enumerate(backends):
                yt, yv, info = observations(mod, directory, U, B, seed, bid, backend, layout, ct, cv)
                y = (ct*yt+cv*yv)/cn
                with torch.no_grad():
                    for kind in METHODS[:3]:
                        fitted, fitinfo = ((y, {}) if kind == 'raw_cutoff' else
                                          mod.cone_fit(y, cn, layout, kind == 'joint_psd_cutoff'))
                        S, T = layout.matrices(fitted, info)
                        G, si = mod.project_measured(S, T, info['beta'], z, int(cn[0]))
                        greens[kind].append(G)
                        audits[kind].append({'fit': fitinfo, 'solve': si})
                for diagonal, name in ((True, 'latent_diagonal_cv'), (False, 'latent_joint_cv')):
                    G, audit = mod.latent_cv(yt, yv, ct, cv, layout, info, z, diagonal)
                    greens[name].append(G)
                    audits[name].append(audit)
            curves = {'omega': omega.tolist(), 'exact': truth.tolist()}
            fresh, values = [], {}
            for name in METHODS:
                spectrum = -sum(greens[name]).imag/math.pi
                require(bool(torch.isfinite(spectrum).all()) and float(spectrum.min()) >= -1e-8,
                        'Gecersiz spektrum.')
                error = float(mod.integral((spectrum-truth).abs(), omega))/mass
                values[name] = error
                fresh.append({'U': U, 'budget': B, 'seed': seed, 'method': name,
                              'relative_L1_window': error, 'actual_shots': used, 'unused_shots': B-used,
                              'shot_weighted_rotation_proxy': 2*int((cn*layout.time_tick_cost).sum())
                              * round(mod.SPACING/mod.PRODUCT_STEP)*(4*(6-1)+6)})
                curves[name] = spectrum.tolist()
            atomic_csv(directory/f'curves_{key}.csv',
                       [{k: v[j] for k, v in curves.items()} for j in range(len(omega))])
            # Commit a complete case before touching aggregate output files.
            atomic_json(directory/'resume_checkpoints'/f'{key}.json',
                        {'key': key, 'settings_sha256': cfg['settings_sha256'], 'rows': fresh, 'details': audits})
            rows.extend(fresh)
            details[key] = audits
            complete.add(key)
            atomic_csv(directory/'metrics.csv', rows)
            atomic_json(directory/'details.json', details)
            log(f'KAYDEDILDI: {len(complete)}/{total}; B={B:.0e}, seed={seed}: ' +
                '; '.join(f'{k}=%{100*v:.3f}' for k, v in values.items()))
    require(len(complete) == total and len(rows) == total*len(METHODS), 'Sonuc tablosu tam degil.')
    # Canonical order: independent of interruption/restart history.
    order = {key_for(float(U), int(B), int(s)): j for j,(U,B,s) in enumerate(
        (U,B,s) for U in cfg['U'] for B in cfg['budgets'] for s in cfg['seeds'])}
    rows.sort(key=lambda r: (order[key_for(r['U'], r['budget'], r['seed'])], METHODS.index(r['method'])))
    atomic_csv(directory/'metrics.csv', rows)
    atomic_json(directory/'details.json', details)
    summary = []
    for U in cfg['U']:
        for B in cfg['budgets']:
            for name in METHODS:
                group = [r for r in rows if r['U'] == U and r['budget'] == B and r['method'] == name]
                summary.append({'U': U, 'budget': B, 'method': name, 'n': len(group),
                                'median_error': statistics.median(r['relative_L1_window'] for r in group),
                                'min_error': min(r['relative_L1_window'] for r in group),
                                'max_error': max(r['relative_L1_window'] for r in group)})
    atomic_json(directory/'summary.json',
                {'status': 'PASS', 'config': cfg, 'summary': summary, 'self_tests': tests,
                 'seconds': None, 'last_resume_seconds': time.perf_counter()-clock,
                 'time_note': 'Original interrupted-run total runtime is unavailable.',
                 'completed_cases': total, 'recovery_session': session})
    log(f'SONUC: PASS — {total}/{total} kosul tamamlandi (yontem ustunlugu iddiasi degil).')
    for U in cfg['U']:
        for B in cfg['budgets']:
            ss = {r['method']: r for r in summary if r['U'] == U and r['budget'] == B}
            log(f'U/t={U:g}, B={B:.0e}, n={len(cfg["seeds"])}: ' +
                '; '.join(f'{k}=%{100*ss[k]["median_error"]:.3f}' for k in METHODS))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--resume', type=Path, required=True, help='Eski run6_... klasoru')
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--check-only', action='store_true', help='Kayitlari say; hesaplama/yedekleme yapma')
    args = parser.parse_args()
    directory = args.resume.expanduser().resolve()
    require(directory.is_dir(), 'Deney klasoru bulunamadi: ' + str(directory))
    session = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:6]
    with (directory/'resume.lock').open('a+') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print('Bu klasor icin bir devam islemi zaten calisiyor.', file=sys.stderr)
            return 2
        logpath = directory/'run.log'
        def log(text: str) -> None:
            print(text, flush=True)
            if not args.check_only:
                with logpath.open('a', encoding='utf-8') as stream:
                    stream.write(text+'\n')
                    stream.flush()
        try:
            cfg, mod, expected = config_and_kernel(directory)
            # Read-only inspection precedes the backup. Early warnings go to terminal.
            rows, details, done = inspect_saved(directory, expected, lambda s: print(s, flush=True))
            print(f'KAYIT KONTROLU: {len(done)}/{len(expected)} tamam; {len(expected)-len(done)} eksik.', flush=True)
            missing = [key_for(*case) for case in expected if key_for(*case) not in done]
            print('EKSIKLER: '+(', '.join(missing) if missing else 'yok'), flush=True)
            if args.check_only:
                return 0
            if len(done) == len(expected) and (directory/'summary.json').exists():
                require(read_json(directory/'summary.json').get('status') == 'PASS', 'Ozet PASS degil.')
                print('SONUC: PASS — bu deney zaten tamamlanmis; hesap tekrarlanmadi.', flush=True)
                target = directory.parent/f'rapor6_{directory.name.removeprefix("run6_")}_tamamlandi.zip'
                archive_directory(directory, target)
                print('RAPOR_ZIP: '+str(target), flush=True)
                return 0
            backup = directory.parent/f'yedek6_{directory.name}_{session}.zip'
            needed = sum(p.stat().st_size for p in directory.rglob('*') if p.is_file() and not p.is_symlink())
            require(shutil.disk_usage(directory.parent).free > 2*needed + 50_000_000,
                    'Yedek ve rapor icin yeterli bos disk alani yok.')
            archive_directory(directory, backup)
            log('YEDEK: '+str(backup))
            log(f'DEVAM: {len(done)}/{len(expected)} korunuyor; {len(missing)} kosul hesaplanacak.')
            atomic_bytes(directory/f'resume_script_{session}.py', Path(__file__).read_bytes())
            atomic_json(directory/f'resume_provenance_{session}.json',
                        {'argv': sys.argv, 'pid': os.getpid(), 'kernel_sha256': KERNEL_SHA256,
                         'resume_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                         'settings_sha256': cfg['settings_sha256'], 'backup': str(backup),
                         'completed_before': len(done), 'missing_before': missing,
                         'scientific_settings_changed': False})
            resume_run(mod, cfg, directory, args.device, rows, details, done, log, session)
            target = directory.parent/f'rapor6_{directory.name.removeprefix("run6_")}_tamamlandi.zip'
            archive_directory(directory, target)
            log('RAPOR_ZIP: '+str(target))
            return 0
        except (Exception, KeyboardInterrupt) as exc:
            text = traceback.format_exc()
            print('HATA: '+str(exc)+'\n'+text, file=sys.stderr, flush=True)
            if not args.check_only:
                atomic_bytes(directory/f'resume_error_{session}.txt', text.encode('utf-8'))
            return 1


if __name__ == '__main__':
    raise SystemExit(main())
